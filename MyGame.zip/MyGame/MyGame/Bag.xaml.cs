﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace MyGame
{
    /// <summary>
    /// Interaction logic for Bag.xaml
    /// </summary>
    public partial class Bag : Window
    {
        int pCount = 3;
        int sCount = 2;
        int hCount = 1;
        public Bag()
        {
            InitializeComponent();

            potionImage.Visibility = Visibility.Hidden;
            superPotionImage.Visibility = Visibility.Hidden;
            hyperPotionImage.Visibility = Visibility.Hidden;

            countPotion.Content = pCount;
            countSuperPotion.Content = sCount;
            countHyperPotion.Content = hCount;

        }

        private void btnPotion_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).potionRestore();
            bool check = ((MainWindow)Application.Current.MainWindow).potionRestore();

            if (check)
            {
                ((MainWindow)Application.Current.MainWindow).cpuBattle();
                pCount -= 1;
            }

            this.Hide();
        }

        private void btnSuperPotion_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).superPotionRestore();
            bool check = ((MainWindow)Application.Current.MainWindow).superPotionRestore();

            if (check)
            {
                ((MainWindow)Application.Current.MainWindow).cpuBattle();
                sCount -= 1;
            }

            this.Hide();
        }

        private void btnHyperPotion_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).hyperPotionRestore();
            bool check = ((MainWindow)Application.Current.MainWindow).hyperPotionRestore();

            if (check == true)
            {
                ((MainWindow)Application.Current.MainWindow).cpuBattle();
                hCount -= 1;
            }

            this.Hide();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void btnPotion_MouseMove(object sender, MouseEventArgs e)
        {
            potionDesc.Content = "Restores the HP of one Pokémon by 20 points.";

            potionImage.Visibility = Visibility.Visible;
            superPotionImage.Visibility = Visibility.Hidden;
            hyperPotionImage.Visibility = Visibility.Hidden;
        }

        private void btnSuperPotion_MouseMove(object sender, MouseEventArgs e)
        {
            potionDesc.Content = "Restores the HP of one Pokémon by 50 points.";

            potionImage.Visibility = Visibility.Hidden;
            superPotionImage.Visibility = Visibility.Visible;
            hyperPotionImage.Visibility = Visibility.Hidden;
        }

        private void btnHyperPotion_MouseMove(object sender, MouseEventArgs e)
        {
            potionDesc.Content = "Restores the HP of one Pokémon by 120 points.";

            potionImage.Visibility = Visibility.Hidden;
            superPotionImage.Visibility = Visibility.Hidden;
            hyperPotionImage.Visibility = Visibility.Visible;
        }

        private void btnCancel_MouseMove(object sender, MouseEventArgs e)
        {
            potionDesc.Content = "Exit out of bag.";

            potionImage.Visibility = Visibility.Hidden;
            superPotionImage.Visibility = Visibility.Hidden;
            hyperPotionImage.Visibility = Visibility.Hidden;
        }
    }
}

