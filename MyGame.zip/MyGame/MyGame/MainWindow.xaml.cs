﻿using MyGame.Models;
using MyGame.ViewModels;
using MyGame.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace MyGame
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {

        public Game game;
        int cpuHP;
        int CurrentUserHP;
        int cpuSpeed;
        int userSpeed;
        int cpuDef;
        int userDef;
        int userAtk;
        int cpuAtk;
        Random r = new Random();
        string currentPokemon;
        string cpuPokemon;
        
        Pokemon pikachu = new Electric("Pikachu", 180, 103, 76, 166, "Ground");
        Pokemon gengar = new Dark("Gengar", 230, 121, 112, 202, "Ground/Ghost/Psychic/Dark");
        Pokemon garchomp = new Dragon("Garchomp", 215, 200, 161, 150, "Dragon/Ice");
        Pokemon Marshstomp = new Water("Marshstomp", 177, 125, 90, 130, "Grass");
        Pokemon Snivy = new Grass("Snivy", 150, 125, 100, 117, "Fire");

        public MainWindow()
        {
            InitializeComponent();
            game = new Game();


            //setup for GameSettings dialog. Event called when its updated.
            GameSettings settings = new GameSettings(game);

            //Show settings, and wait for it to complete. 
            settings.ShowDialog();

            //set dataContext to Game
            DataContext = game;

            gameStart();

        }
        public int Maximum { get; set; }

        public void changeDefaultPokemon(string cpuPokemon, string userPokemon)
        {
            if (cpuPokemon == "Gengar") { cpuHP = gengar.hp; cpuSpeed = gengar.speed; cpuDef = gengar.defense; cpuPN.Text = gengar.Name; cpuAtk = gengar.attack; }
            if (cpuPokemon == "Garchomp") { cpuHP = garchomp.hp; cpuSpeed = garchomp.speed; cpuDef = garchomp.defense; cpuPN.Text = garchomp.Name; cpuAtk = garchomp.attack; }
            if (cpuPokemon == "Pikachu") { cpuHP = pikachu.hp; cpuSpeed = pikachu.speed; cpuDef = pikachu.defense; cpuPN.Text = pikachu.Name; cpuAtk = pikachu.attack; }
            if (cpuPokemon == "Snivy") { cpuHP = Snivy.hp; cpuSpeed = Snivy.speed; cpuDef = Snivy.defense; cpuPN.Text = Snivy.Name; cpuAtk = Snivy.attack; }
            if (cpuPokemon == "Marshtomp") { cpuHP = Marshstomp.hp; cpuSpeed = Marshstomp.speed; cpuDef = Marshstomp.defense; cpuPN.Text = Marshstomp.Name; cpuAtk = Marshstomp.attack; }

            if (userPokemon == "Gengar") { CurrentUserHP = gengar.hp; userSpeed = gengar.speed; userDef = gengar.defense; userPN.Text = gengar.Name; userAtk = gengar.attack; }
            if (userPokemon == "Garchomp") { CurrentUserHP = garchomp.hp; userSpeed = garchomp.speed; userDef = garchomp.defense; userPN.Text = garchomp.Name; userAtk = garchomp.attack; }
            if (userPokemon == "Pikachu") { CurrentUserHP = pikachu.hp; userSpeed = pikachu.speed; userDef = pikachu.defense; userPN.Text = pikachu.Name; userAtk = pikachu.attack; }
            if (userPokemon == "Snivy") { CurrentUserHP = Snivy.hp; userSpeed = Snivy.speed; userDef = Snivy.defense; userPN.Text = Snivy.Name; userAtk = Snivy.attack; }
            if (userPokemon == "Marshtomp") { CurrentUserHP = Marshstomp.hp; userSpeed = Marshstomp.speed; userDef = Marshstomp.defense; userPN.Text = Marshstomp.Name; userAtk = Marshstomp.attack; }
        }
        //Starts Game
        private void gameStart()
        {

            cpuPokemon = game.CpuPokemon;
            currentPokemon = game.UserPokemon;
            changeDefaultPokemon(cpuPokemon, currentPokemon);


            Hbar_1.Maximum = cpuHP;
            Hbar_2.Maximum = CurrentUserHP;

            txtHP1.Text = Hbar_1.Value + " / " + Hbar_1.Maximum;
            txtHP2.Text = Hbar_2.Value + "/" + Hbar_2.Maximum;
        }
        //Updates Current Health in healthBar
        public void updateCHealth()
        {
            if (cpuHP <= 0)
            {

                cpuHP = 0;
                txtHP1.Text = Hbar_1.Value + " / " + Hbar_1.Maximum;

            }
            if (CurrentUserHP <= 0)
            {
                CurrentUserHP = 0;
                txtHP1.Text = Hbar_1.Value + " / " + Hbar_1.Maximum;
            }
            else
            {
                txtHP1.Text = Hbar_1.Value + " / " + Hbar_1.Maximum;
                txtHP2.Text = Hbar_2.Value + "/" + Hbar_2.Maximum;
            }


        }
        //Swaps to move menu
        private void btnFight_Click(object sender, RoutedEventArgs e)
        {
            sGrid.Visibility = Visibility.Hidden;
            mGrid.Visibility = Visibility.Visible;
            if (currentPokemon == "Pikachu")
            {
                btnMove1.Content = "Thunderbolt";
                btnMove2.Content = "ElectroShock";
                btnMove3.Content = "Quick Attack";
                btnMove4.Content = "Iron Tail";
            }
            if (currentPokemon == "Garchomp")
            {
                btnMove1.Content = "Earthquake";
                btnMove2.Content = "Dragon Claw";
                btnMove3.Content = "Dragon Dance";
                btnMove4.Content = "Draco Meteor";
            }
            if (currentPokemon == "Gengar")
            {
                btnMove1.Content = "Shadow Claw";
                btnMove2.Content = "Persuit";
                btnMove3.Content = "Hex";
                btnMove4.Content = "Shadow Ball";
            }
            if (currentPokemon == "Snivy")
            {
                btnMove1.Content = "Leaf Tornado";
                btnMove2.Content = "Vine Whip";
                btnMove3.Content = "Leer";
                btnMove4.Content = "Quick Attack";
            }
            if (currentPokemon == "Marshtomp")
            {
                btnMove1.Content = "Dirty Water";
                btnMove2.Content = "Surf";
                btnMove3.Content = "Take Down";
                btnMove4.Content = "Defense Curl";
            }


            txtUpdateUser.Text = "Choose a move " + game.PlayerName;


        }
        //Check for crits or misses
        private string critOrMiss()
        {
            string critOrMiss = "";
            int rValue = r.Next(1, 101);
            if (rValue <= 80)
            {
                critOrMiss = "Hit";
            }
            if (rValue >= 91 && rValue <= 100)
            {
                critOrMiss = "Crit";
            }
            if (rValue >= 81 && rValue <= 90)
            {
                critOrMiss = "Missed";
            }

            return critOrMiss;
        }
        //Check totalDmgDealt including defense values
        private int totalDmgDealt(int moveDmg, int pDefense, string critOrMiss)
        {
            int totalDmgDealt = moveDmg - pDefense / 4;
            if (critOrMiss == "Hit")
            {
                totalDmgDealt = moveDmg - pDefense / 4;
            }
            if (critOrMiss == "Missed")
            {
                totalDmgDealt = 0;

            }
            if (critOrMiss == "Crit")
            {
                totalDmgDealt = totalDmgDealt * 2;
            }

            return totalDmgDealt;
        }
        //Quits game
        private void btnQuit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        //Gets random move for cpu to choose
        private void cpuMove(string critOrMis)
        {

            int move1Dmg = 45;
            int move2dmg = 55;
            int move3dmg = 65;
            int move4dmg = 60;
            int whichMove = r.Next(1, 5);

            if (whichMove == 1)
            {
                CurrentUserHP -= totalDmgDealt(move1Dmg, userDef, critOrMis);
                Hbar_2.Value = CurrentUserHP;
                updateCHealth();
            }
            if (whichMove == 2)
            {
                CurrentUserHP -= totalDmgDealt(move2dmg, userDef, critOrMis);
                Hbar_2.Value = CurrentUserHP;
                updateCHealth();
            }
            if (whichMove == 3)
            {
                CurrentUserHP -= totalDmgDealt(move3dmg, userDef, critOrMis);
                Hbar_2.Value = CurrentUserHP;
                updateCHealth();
            }
            if (whichMove == 4)
            {
                CurrentUserHP -= totalDmgDealt(move4dmg, userDef, critOrMis);
                Hbar_2.Value = CurrentUserHP;
                updateCHealth();
            }
        }
        public void battle(int dmgDealt, string critOrMis, string critOrMis2, string moveName, bool statMove, string whatStatM)
        {
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };
            if (statMove == false)
            {
                if (check_Speed() == currentPokemon)
                {
                    cpuHP -= totalDmgDealt(dmgDealt, cpuDef, critOrMis);
                    Hbar_1.Value = cpuHP;
                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack";
                    gif.Visibility = Visibility.Visible;

                    timer.Start();
                    timer.Tick += (sender, args) =>
                    {
                        timer.Stop();
                        txtUpdateUser.Text = cpuPokemon + " attack " + critOrMis2;
                        cpuMove(critOrMis2);
                        updateCHealth();
                        sGrid.Visibility = Visibility.Visible;
                        mGrid.Visibility = Visibility.Hidden;
                        gif.Visibility = Visibility.Hidden;
                        checkForWin();


                    };
                }

                if (check_Speed() == cpuPokemon)
                {
                    cpuMove(critOrMis2);
                    txtUpdateUser.Text = cpuPokemon + " attack " + critOrMis2;
                    gif.Visibility = Visibility.Visible;

                    timer.Start();

                    timer.Tick += (sender, args) =>
                    {
                        timer.Stop();

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it was a " + critOrMis + " attack";
                        cpuHP -= totalDmgDealt(dmgDealt, cpuDef, critOrMis);
                        Hbar_1.Value = cpuHP;
                        updateCHealth();

                        sGrid.Visibility = Visibility.Visible;
                        mGrid.Visibility = Visibility.Hidden;
                        gif.Visibility = Visibility.Hidden;

                        checkForWin();

                    };
                }
            }
            else
            {
                if (check_Speed() == currentPokemon)
                {
                    cpuHP -= totalDmgDealt(dmgDealt, cpuDef, critOrMis);
                    Hbar_1.Value = cpuHP;
                    txtUpdateUser.Text = currentPokemon + " used " + moveName + " " + whatStatM;
                    gif.Visibility = Visibility.Visible;

                    timer.Start();
                    timer.Tick += (sender, args) =>
                    {
                        timer.Stop();
                        txtUpdateUser.Text = cpuPokemon + " attack " + critOrMis2;
                        cpuMove(critOrMis2);
                        updateCHealth();
                        sGrid.Visibility = Visibility.Visible;
                        mGrid.Visibility = Visibility.Hidden;
                        gif.Visibility = Visibility.Hidden;
                        checkForWin();


                    };
                }

                if (check_Speed() == cpuPokemon)
                {
                    cpuMove(critOrMis2);
                    txtUpdateUser.Text = cpuPokemon + " attack " + critOrMis2;
                    gif.Visibility = Visibility.Visible;

                    timer.Start();

                    timer.Tick += (sender, args) =>
                    {
                        timer.Stop();

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + " " + whatStatM;
                        cpuHP -= totalDmgDealt(dmgDealt, cpuDef, critOrMis);
                        Hbar_1.Value = cpuHP;
                        updateCHealth();

                        sGrid.Visibility = Visibility.Visible;
                        mGrid.Visibility = Visibility.Hidden;
                        gif.Visibility = Visibility.Hidden;

                        checkForWin();

                    };
                }
            }

        }
        //This is to check move dmg and using total dmg dealt deals dmg (Want to add speed stats to see who goes first)
        private void btnMove_click(object sender, RoutedEventArgs e)
        {
            string currentMove = (sender as Button).Content.ToString();
            string critOrMis = critOrMiss();
            string critOrMis2 = critOrMiss();
            int i = 0;
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };

            switch (currentMove)
            {
                case "Thunderbolt":
                    mGrid.Visibility = Visibility.Hidden;
                    int dmgDealt = 100;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Thunderbolt", false, "");
                    break;
                case "ElectroShock":
                    dmgDealt = 50;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "ElectroShock", false, "");
                    break;
                case "Quick Attack":
                    int previousSpeed = userSpeed;
                    userSpeed = 5000;
                    dmgDealt = 45;
                    mGrid.Visibility = Visibility.Hidden;

                    if (check_Speed() == currentPokemon)
                    {
                        cpuHP -= totalDmgDealt(dmgDealt, cpuDef, critOrMis);
                        Hbar_1.Value = cpuHP;
                        txtUpdateUser.Text = currentPokemon + " used quick attack and it was a " + critOrMis + " attack";
                        gif.Visibility = Visibility.Visible;
                        timer.Start();
                        timer.Tick += (sender, args) =>
                        {
                            timer.Stop();
                            txtUpdateUser.Text = cpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            updateCHealth();
                            userSpeed = previousSpeed;
                            sGrid.Visibility = Visibility.Visible;
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Hidden;
                            checkForWin();
                        };
                    }
                    break;
                case "Earthquake":
                    dmgDealt = 85;
                    userSpeed -= 10;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Earthquake", false, "");
                    break;
                case "Dragon Claw":
                    dmgDealt = 65;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Dragon Claw", false, "");
                    break;
                case "Dragon Dance":
                    dmgDealt = 0;
                    mGrid.Visibility = Visibility.Hidden;
                    userAtk += 20;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Dragon Drance ", true, currentPokemon + "'s Attack increased");
                    break;
                case "Draco Meteor":
                    dmgDealt = 140;
                    mGrid.Visibility = Visibility.Hidden;
                    userAtk -= 20;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Draco Meteor ", false, "");
                    break;
                case "Shadow Claw":
                    dmgDealt = 60;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Shadow Claw ", false, "");
                    break;
                case "Persuit":
                    dmgDealt = 50;
                    if (userSpeed > cpuSpeed) { dmgDealt = 100; }
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Persuit", false, "");
                    break;
                case "Hex":
                    dmgDealt = 75;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Hex", false, "");
                    i += 1;
                    break;
                case "Shadow Ball":
                    dmgDealt = 40;
                    if (i >= 1) { dmgDealt = 70; }
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Shadow Ball", false, "");
                    break;
                case "Leaf Tornado":
                    dmgDealt = 80;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Lear Tornado", false, "");
                    break;
                case "Vine Whip":
                    dmgDealt = 50;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Wine Whip", false, "");
                    break;
                case "Leer":
                    dmgDealt = 0;
                    cpuDef -= 25;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Leer", true, cpuPokemon + "'s Defense Decreased");
                    break;
                case "Dirty Water":
                    dmgDealt = 100;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Dirty Water", false, "");
                    break;
                case "Surf":
                    dmgDealt = 90;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Surf", false, "");
                    break;
                case "Take Down":
                    dmgDealt = 80;
                    CurrentUserHP -= 10;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Take Down", false, "");
                    txtUpdateUser.Text = currentPokemon + " was hurt by recoil";
                    break;
                case "Defense Curl":
                    dmgDealt = 0;
                    userDef += userDef / 5;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMiss(), critOrMiss(), "Surf", false, currentPokemon + "'s Defense Increased");
                    txtUpdateUser.Text = currentPokemon + " was hurt by recoil";
                    break;
            }
        }
        private string check_Speed()
        {
            string whoFirst = "";
            if (cpuSpeed > userSpeed)
            {
                whoFirst = cpuPokemon;
            }
            if (userSpeed > cpuSpeed)
            {
                whoFirst = currentPokemon;
            }
            return whoFirst;
        }
        //Checks to see if someone won
        private void checkForWin()
        {

            if (Hbar_1.Value <= 0)
            {
                imgCpu.Visibility = Visibility.Hidden;
                updateCHealth();
                txtUpdateUser.Text = cpuPokemon + " has feinted the winner is " + game.PlayerName;
            }
            if (Hbar_2.Value <= 0)
            {
                imgUser.Visibility = Visibility.Hidden;
                updateCHealth();
                txtUpdateUser.Text = currentPokemon + " has feineted the winner is CPU";
            }


        }
    }


}







