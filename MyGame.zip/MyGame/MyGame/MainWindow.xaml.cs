﻿using MyGame.Models;
using MyGame.Views;
using System;
using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace MyGame
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {

        public Game game;
        //Global Stat usage
        string cpuStatus = "";
        string userStatus;
        int cpuHP;
        int CurrentUserHP;
        int cpuSpeed;
        int userSpeed;
        int cpuDef;
        int userDef;
        int pokeHp;
        int cpuMaxHP;
        bool isAsleep = false;
        string cpuType;
        string userType;
        bool won = false;
        Random r = new Random();
        int sleepCount = 0;
        bool hasStatus = false;
        string critOrMis2;
        private string effectiveNess;


        //Current Pokemon
        string currentPokemon;
        string cpuPokemon;
        bool moved;
        Pokemon pikachu = new Electric("Pikachu", 180, 103, 100, 166, "Ground");
        Pokemon gengar = new Dark("Gengar", 230, 121, 112, 202, "Ground/Ghost/Psychic/Dark");
        Pokemon garchomp = new Dragon("Garchomp", 170, 200, 161, 150, "Dragon/Ice");
        Pokemon Swampert = new Water("Swampert", 150, 125, 90, 130, "Grass");
        Pokemon Snivy = new Grass("Snivy", 150, 125, 100, 117, "Fire");
        Pokemon Doduo = new Flying("Doduo", 142, 125, 100, 165, "Rock/Electric");
        Pokemon Oddish = new Grass("Oddish", 200, 60, 103, 70, "Fire/Ice/Fly/Psy");
        Pokemon Flareon = new Fire("Flareon", 240, 150, 100, 100, "Water/Ground/Rock");
        Pokemon Hydreigon = new Dragon("Hydreigon", 290, 100, 160, 95, "Ice/Fighting/Bug/Dragon/Fairy");
        Pokemon Slowking = new Psychic("Slowking", 275, 100, 140, 30, "Electric/Grass/Bug/Ghost/Dark");
        private int cpuAtk;
        private int userAtk;



        public MainWindow()
        {
            InitializeComponent();
            game = new Game();


            //setup for GameSettings dialog. Event called when its updated.
            GameSettings settings = new GameSettings(game);

            //Show settings, and wait for it to complete. 
            settings.ShowDialog();

            //set dataContext to Game
            DataContext = game;

            gameStart();

        }
        private void btnBag_Click(object sender, RoutedEventArgs e)
        {
            Bag bag = new();
            bag.Show();
        }
        //Restores Pokemon's HP by 20
        public bool potionRestore()
        {
            bool isHealed = false;
            if (CurrentUserHP >= Hbar_2.Maximum)
            {
                txtUpdateUser.Text = currentPokemon + "'s HP is already full.";
            }
            else if (CurrentUserHP != 0)
            {
                CurrentUserHP += 20;
                isHealed = true;

                if (CurrentUserHP > Hbar_2.Maximum)
                {
                    CurrentUserHP = (int)Hbar_2.Maximum;
                    Hbar_2.Value = CurrentUserHP;
                    updateCHealth();
                    txtUpdateUser.Text = currentPokemon + "'s HP was restored by 20 points.";
                }
                if (Hbar_2.Value > Hbar_2.Maximum)
                {
                    Hbar_2.Value = Hbar_2.Maximum;
                }
            }

            return isHealed;
        }
        //Restores Pokemon's HP by 50
        public bool superPotionRestore()
        {
            bool isHealed = false;
            if (CurrentUserHP >= Hbar_2.Maximum)
            {
                txtUpdateUser.Text = currentPokemon + "'s HP is already full.";
            }
            else if (CurrentUserHP != 0)
            {
                CurrentUserHP += 50;
                isHealed = true;

                if (CurrentUserHP > Hbar_2.Maximum)
                {
                    CurrentUserHP = (int)Hbar_2.Maximum;
                    Hbar_2.Value = CurrentUserHP;
                    updateCHealth();
                    txtUpdateUser.Text = currentPokemon + "'s HP was restored by 50 points.";
                }
                if (Hbar_2.Value > Hbar_2.Maximum)
                {
                    Hbar_2.Value = Hbar_2.Maximum;
                }
            }


            return isHealed;
        }
        //Restores Pokemon's HP by 50
        public bool hyperPotionRestore()
        {
            bool isHealed = false;
            if (CurrentUserHP >= Hbar_2.Maximum)
            {
                txtUpdateUser.Text = currentPokemon + "'s HP is already full.";
            }
            else if (CurrentUserHP != 0)
            {
                CurrentUserHP += 120;
                isHealed = true;

                if (CurrentUserHP > Hbar_2.Maximum)
                {
                    CurrentUserHP = (int)Hbar_2.Maximum;
                    Hbar_2.Value = CurrentUserHP;
                    updateCHealth();
                    txtUpdateUser.Text = currentPokemon + "'s HP was restored by 120 points.";
                }
                if (Hbar_2.Value > Hbar_2.Maximum)
                {
                    Hbar_2.Value = Hbar_2.Maximum;
                }
            }

            return isHealed;
        }
        private void cpuMove(string critOrMis)
        {
            Move firstMove = new Move(1, 45, "Water");
            Move secondMove = new Move(2, 55, "Water");
            Move thirdMove = new Move(3, 65, "Water");
            Move fourthMove = new Move(4, 60, "Water");
            int[] weightedMoves = new int[10];
            ArrayList availableArraySpots = new ArrayList();
            for (int i = 0; i < 10; i++)
            {
                availableArraySpots.Add(i);
            }


            if (cpuPokemon == "Pikachu")
            {
                firstMove.type = "Electric";
                secondMove.type = "Electric";
                thirdMove.type = "Normal";
                thirdMove.type = "Steel";
            }
            if (cpuPokemon == "Gengar")
            {
                firstMove.type = "Dark";
                secondMove.type = "Dark";
                thirdMove.type = "Ghost";
                fourthMove.type = "Ghost";
            }
            if (cpuPokemon == "Garchomp")
            {
                firstMove.type = "Ground";
                secondMove.type = "Dragon";
                thirdMove.type = "Dragon";
                fourthMove.type = "Dragon";
            }
            if (cpuPokemon == "Snivy")
            {
                firstMove.type = "Grass";
                secondMove.type = "Grass";
                thirdMove.type = "Normal";
                fourthMove.type = "Normal";
            }
            if (cpuPokemon == "Swampert")
            {
                firstMove.type = "Water";
                secondMove.type = "Water";
                thirdMove.type = "Normal";
                fourthMove.type = "Water";
            }




            Move[] availableMoves = { firstMove, secondMove, thirdMove, fourthMove };
            Array.Sort(availableMoves, new moveComparer());

            while (availableArraySpots.Count > 0)
            {

                int listSpot;

                int highValue = 5;
                int medValue = 3;
                int lowValue = 1;

                for (int i = 0; i < lowValue; i++)
                {
                    listSpot = r.Next(availableArraySpots.Count);
                    int e = (int)availableArraySpots[listSpot];
                    weightedMoves[e] = availableMoves[0].moveSlot;
                    availableArraySpots.RemoveAt(listSpot);
                }

                for (int i = 0; i < lowValue; i++)
                {
                    listSpot = r.Next(availableArraySpots.Count);
                    int e = (int)availableArraySpots[listSpot];
                    weightedMoves[e] = availableMoves[1].moveSlot;
                    availableArraySpots.RemoveAt(listSpot);
                }
                for (int i = 0; i < medValue; i++)
                {
                    listSpot = r.Next(availableArraySpots.Count);
                    int e = (int)availableArraySpots[listSpot];
                    weightedMoves[e] = availableMoves[2].moveSlot;
                    availableArraySpots.RemoveAt(listSpot);
                }

                for (int i = 0; i < highValue; i++)
                {
                    listSpot = r.Next(availableArraySpots.Count);
                    int e = (int)availableArraySpots[listSpot];
                    weightedMoves[e] = availableMoves[3].moveSlot;
                    availableArraySpots.RemoveAt(listSpot);
                }

            }

            int whichMove = weightedMoves[r.Next(weightedMoves.Length)];
            int random = r.Next(3);

            if (whichMove == 1)
            {
                CurrentUserHP -= totalDmgDealt(firstMove.damage, userDef, critOrMis, firstMove.type, userType, cpuAtk);
                Hbar_2.Value = CurrentUserHP;
                updateCHealth();

            }
            if (whichMove == 2)
            {
                CurrentUserHP -= totalDmgDealt(secondMove.damage, userDef, critOrMis, secondMove.type, userType, cpuAtk);
                Hbar_2.Value = CurrentUserHP;
                updateCHealth();
            }
            if (whichMove == 3)
            {
                CurrentUserHP -= totalDmgDealt(thirdMove.damage, userDef, critOrMis, thirdMove.type, userType, cpuAtk);
                Hbar_2.Value = CurrentUserHP;

                updateCHealth();
            }
            if (whichMove == 4)
            {
                CurrentUserHP -= totalDmgDealt(fourthMove.damage, userDef, critOrMis, fourthMove.type, userType, cpuAtk);

                Hbar_2.Value = CurrentUserHP;

                updateCHealth();
            }

            //txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis;

        }
        public int Maximum { get; set; }
        public void changeDefaultPokemon(string cpuPokemon, string userPokemon)
        {

            if (cpuPokemon == "Gengar") { cpuHP = gengar.hp; cpuSpeed = gengar.speed; cpuDef = gengar.defense; cpuPN.Text = gengar.Name; cpuAtk = gengar.attack; imgCpuGen.Visibility = Visibility.Visible; cpuMaxHP = gengar.hp; cpuType = "Ghost"; }
            if (cpuPokemon == "Garchomp") { cpuHP = garchomp.hp; cpuSpeed = garchomp.speed; cpuDef = garchomp.defense; cpuPN.Text = garchomp.Name; cpuAtk = garchomp.attack; imgCpuG.Visibility = Visibility.Visible; cpuMaxHP = garchomp.hp; cpuType = "Dragon"; }
            if (cpuPokemon == "Pikachu") { cpuHP = pikachu.hp; cpuSpeed = pikachu.speed; cpuDef = pikachu.defense; cpuPN.Text = pikachu.Name; cpuAtk = pikachu.attack; imgCpuP.Visibility = Visibility.Visible; cpuMaxHP = pikachu.hp; cpuType = "Electric"; }
            if (cpuPokemon == "Snivy") { cpuHP = Snivy.hp; cpuSpeed = Snivy.speed; cpuDef = Snivy.defense; cpuPN.Text = Snivy.Name; cpuAtk = Snivy.attack; imgCpuSn.Visibility = Visibility.Visible; cpuMaxHP = Snivy.hp; cpuType = "Grass"; }
            if (cpuPokemon == "Swampert") { cpuHP = Swampert.hp; cpuSpeed = Swampert.speed; cpuDef = Swampert.defense; cpuPN.Text = Swampert.Name; cpuAtk = Swampert.attack; imgCpuS.Visibility = Visibility.Visible; cpuMaxHP = Swampert.hp; cpuType = "Water"; }
            if (cpuPokemon == "Flareon") { cpuHP = Flareon.hp; cpuSpeed = Flareon.speed; cpuDef = Flareon.defense; cpuPN.Text = Flareon.Name; cpuAtk = Flareon.attack; imgCpuFlare.Visibility = Visibility.Visible; cpuMaxHP = Flareon.hp; cpuType = "Fire"; }
            if (cpuPokemon == "Oddish") { cpuHP = Oddish.hp; cpuSpeed = Oddish.speed; cpuDef = Oddish.defense; cpuPN.Text = Oddish.Name; cpuAtk = Oddish.attack; imgCpuOdd.Visibility = Visibility.Visible; cpuMaxHP = Oddish.hp; cpuType = "Grass/Poison"; }
            if (cpuPokemon == "Hydreigon") { cpuHP = Hydreigon.hp; cpuSpeed = Hydreigon.speed; cpuDef = Hydreigon.defense; cpuPN.Text = Hydreigon.Name; cpuAtk = Hydreigon.attack; imgCpuHydra.Visibility = Visibility.Visible; cpuMaxHP = Hydreigon.hp; cpuType = "Dragon/Flying"; }
            if (cpuPokemon == "Slowking") { cpuHP = Slowking.hp; cpuSpeed = Slowking.speed; cpuDef = Slowking.defense; cpuPN.Text = Slowking.Name; cpuAtk = Slowking.attack; imgCpuSlow.Visibility = Visibility.Visible; cpuMaxHP = Slowking.hp; cpuType = "Psychic"; }
            if (cpuPokemon == "Doduo") { cpuHP = Doduo.hp; cpuSpeed = Doduo.speed; cpuDef = Doduo.defense; cpuPN.Text = Doduo.Name; cpuAtk = Doduo.attack; imgCpuDo.Visibility = Visibility.Visible; cpuMaxHP = Doduo.hp; cpuType = "Flying"; }

            if (userPokemon == "Gengar") { CurrentUserHP = gengar.hp; userSpeed = gengar.speed; userDef = gengar.defense; userPN.Text = gengar.Name; userAtk = gengar.attack; imgUserGen.Visibility = Visibility.Visible; pokeHp = gengar.hp; userType = "Ghost"; }
            if (userPokemon == "Garchomp") { CurrentUserHP = garchomp.hp; userSpeed = garchomp.speed; userDef = garchomp.defense; userPN.Text = garchomp.Name; userAtk = garchomp.attack; imgUserG.Visibility = Visibility.Visible; pokeHp = garchomp.hp; userType = "Dragon"; }
            if (userPokemon == "Pikachu") { CurrentUserHP = pikachu.hp; userSpeed = pikachu.speed; userDef = pikachu.defense; userPN.Text = pikachu.Name; userAtk = pikachu.attack; imgUserP.Visibility = Visibility.Visible; pokeHp = pikachu.hp; userType = "Electric"; }
            if (userPokemon == "Snivy") { CurrentUserHP = Snivy.hp; userSpeed = Snivy.speed; userDef = Snivy.defense; userPN.Text = Snivy.Name; userAtk = Snivy.attack; imgUserSn.Visibility = Visibility.Visible; pokeHp = Snivy.hp; userType = "Grass"; }
            if (userPokemon == "Swampert") { CurrentUserHP = Swampert.hp; userSpeed = Swampert.speed; userDef = Swampert.defense; userPN.Text = Swampert.Name; userAtk = Swampert.attack; imgUserS.Visibility = Visibility.Visible; pokeHp = Swampert.hp; userType = "Water"; }
            if (userPokemon == "Flareon") { CurrentUserHP = Flareon.hp; userSpeed = Flareon.speed; userDef = Flareon.defense; userPN.Text = Flareon.Name; userAtk = Flareon.attack; imgUserFlare.Visibility = Visibility.Visible; pokeHp = gengar.hp; userType = "Ghost"; }
            if (userPokemon == "Oddish") { CurrentUserHP = Oddish.hp; userSpeed = Oddish.speed; userDef = Oddish.defense; userPN.Text = Oddish.Name; userAtk = Oddish.attack; imgUserOdd.Visibility = Visibility.Visible; pokeHp = Oddish.hp; userType = "Grass/Poison"; }
            if (userPokemon == "Hydreigon") { CurrentUserHP = Hydreigon.hp; userSpeed = Hydreigon.speed; userDef = Hydreigon.defense; userPN.Text = Hydreigon.Name; userAtk = Hydreigon.attack; imgUserHydra.Visibility = Visibility.Visible; pokeHp = Hydreigon.hp; userType = "Dragon/Flying"; }
            if (userPokemon == "Slowking") { CurrentUserHP = Slowking.hp; userSpeed = Slowking.speed; userDef = Slowking.defense; userPN.Text = Slowking.Name; userAtk = Slowking.attack; imgUserSlow.Visibility = Visibility.Visible; pokeHp = Slowking.hp; userType = "Psyhic"; }
            if (userPokemon == "Doduo") { CurrentUserHP = Doduo.hp; userSpeed = Doduo.speed; userDef = Doduo.defense; userPN.Text = Doduo.Name; userAtk = Doduo.attack; imgUserDo.Visibility = Visibility.Visible; pokeHp = Doduo.hp; userType = "Flying"; }
        }
        //Starts Game
        private void gameStart()
        {
            cpuPokemon = game.CpuPokemon;
            currentPokemon = game.UserPokemon;
            changeDefaultPokemon(cpuPokemon, currentPokemon);



            Hbar_1.Maximum = cpuMaxHP;
            Hbar_2.Maximum = pokeHp;

            txtHP2.Text = Hbar_2.Value + "/" + Hbar_2.Maximum;
        }
        //Updates Current Health in healthBar
        public void updateCHealth()
        {

            if (CurrentUserHP <= 0)
            {
                CurrentUserHP = 0;
                txtHP2.Text = Hbar_2.Value + " / " + Hbar_2.Maximum;

            }
            else
            {

                txtHP2.Text = Hbar_2.Value + "/" + Hbar_2.Maximum;
            }


        }
        //Swaps to move menu
        private void btnFight_Click(object sender, RoutedEventArgs e)
        {
            sGrid.Visibility = Visibility.Hidden;
            mGrid.Visibility = Visibility.Visible;
            if (game.UserPokemon == "Pikachu")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Yellow);
                btnMove2.Background = new SolidColorBrush(Colors.Yellow);
                btnMove3.Background = new SolidColorBrush(Colors.Gray);
                btnMove4.Background = new SolidColorBrush(Colors.Silver);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Yellow);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Yellow);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Silver);


                btnMove1.Content = "Thunderbolt";
                btnMove2.Content = "Thunder Wave";
                btnMove3.Content = "Quick Attack";
                btnMove4.Content = "Iron Tail";
            }

            if (game.UserPokemon == "Garchomp")
            {

                btnMove1.Background = new SolidColorBrush(Colors.SandyBrown);
                btnMove2.Background = new SolidColorBrush(Colors.BlueViolet);
                btnMove3.Background = new SolidColorBrush(Colors.BlueViolet);
                btnMove4.Background = new SolidColorBrush(Colors.BlueViolet);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.SandyBrown);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.BlueViolet);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.BlueViolet);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.BlueViolet);


                btnMove1.Content = "Earthquake";
                btnMove2.Content = "Dragon Claw";
                btnMove3.Content = "Dragon Dance";
                btnMove4.Content = "Draco Meteor";
            }
            if (game.UserPokemon == "Gengar")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Brown);
                btnMove2.Background = new SolidColorBrush(Colors.Brown);
                btnMove3.Background = new SolidColorBrush(Colors.Purple);
                btnMove4.Background = new SolidColorBrush(Colors.Purple);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Brown);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Brown);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Purple);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Purple);

                btnMove1.Content = "Shadow Claw";
                btnMove2.Content = "Lick";
                btnMove3.Content = "Hex";
                btnMove4.Content = "Shadow Ball";
            }
            if (game.UserPokemon == "Snivy")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Green);
                btnMove2.Background = new SolidColorBrush(Colors.Green);
                btnMove3.Background = new SolidColorBrush(Colors.Gray);
                btnMove4.Background = new SolidColorBrush(Colors.Gray);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Green);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Green);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Gray);

                btnMove1.Content = "Leaf Tornado";
                btnMove2.Content = "Vine Whip";
                btnMove3.Content = "Take Down";
                btnMove4.Content = "Leer";
            }
            if (game.UserPokemon == "Swampert")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Blue);
                btnMove2.Background = new SolidColorBrush(Colors.Blue);
                btnMove3.Background = new SolidColorBrush(Colors.Gray);
                btnMove4.Background = new SolidColorBrush(Colors.Blue);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Blue);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Blue);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Blue);

                btnMove1.Content = "Dirty Water";
                btnMove2.Content = "Surf";
                btnMove3.Content = "Take Down";
                btnMove4.Content = "Defense Curl";
            }
            if (game.UserPokemon == "Doduo")
            {

                btnMove1.Background = new SolidColorBrush(Colors.LightBlue);
                btnMove1.Foreground = new SolidColorBrush(Colors.Gray);
                btnMove2.Background = new SolidColorBrush(Colors.Gray);
                btnMove3.Background = new SolidColorBrush(Colors.Pink);
                btnMove4.Background = new SolidColorBrush(Colors.Gray);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.LightBlue);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Pink);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Gray);


                btnMove1.Content = "Drill Peck";
                btnMove2.Content = "Sword Dance";
                btnMove3.Content = "Agility";
                btnMove4.Content = "Quick Attack";
            }
            if (game.UserPokemon == "Slowking")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Gray);
                btnMove2.Background = new SolidColorBrush(Colors.Pink);
                btnMove3.Background = new SolidColorBrush(Colors.Gray);
                btnMove4.Background = new SolidColorBrush(Colors.Pink);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Pink);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Pink);

                btnMove1.Content = "Yawn";
                btnMove2.Content = "Zen Headbutt";
                btnMove3.Content = "Psych Up";
                btnMove4.Content = "Confusion";
            }
            if (game.UserPokemon == "Hydreigon")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Brown);
                btnMove2.Background = new SolidColorBrush(Colors.BlueViolet);
                btnMove3.Background = new SolidColorBrush(Colors.Gray);
                btnMove4.Background = new SolidColorBrush(Colors.Gray);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Brown);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.BlueViolet);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Gray);

                btnMove1.Content = "Bite";
                btnMove2.Content = "Dragon Breath";
                btnMove3.Content = "Hyper Beam";
                btnMove4.Content = "Tri Attack";
            }
            if (game.UserPokemon == "Flareon")
            {

                btnMove1.Background = new SolidColorBrush(Colors.OrangeRed);
                btnMove2.Background = new SolidColorBrush(Colors.Gray);
                btnMove3.Background = new SolidColorBrush(Colors.OrangeRed);
                btnMove4.Background = new SolidColorBrush(Colors.Gray);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.OrangeRed);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.OrangeRed);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Gray);

                btnMove1.Content = "Fire Fang";
                btnMove2.Content = "Quick Attack";
                btnMove3.Content = "Lava Plume";
                btnMove4.Content = "Growl";
            }
            if (game.UserPokemon == "Oddish")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Purple);
                btnMove2.Background = new SolidColorBrush(Colors.Green);
                btnMove3.Background = new SolidColorBrush(Colors.Green);
                btnMove4.Background = new SolidColorBrush(Colors.Green);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Purple);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Green);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Green);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Green);

                btnMove1.Content = "Poison Powder";
                btnMove2.Content = "Giga Drain";
                btnMove3.Content = "Stun Spore";
                btnMove4.Content = "Growth";
            }


            txtUpdateUser.Text = "Choose a move " + game.PlayerName;


        }
        //Check for crits or misses
        private string critOrMiss()
        {
            string critOrMiss = "";
            int rValue = r.Next(1, 101);
            if (rValue <= 80)
            {
                critOrMiss = "Hit";
            }
            if (rValue >= 91 && rValue <= 100)
            {
                critOrMiss = "Crit";
            }
            if (rValue >= 81 && rValue <= 90)
            {
                critOrMiss = "Missed";
            }

            return critOrMiss;
        }
        //Check totalDmgDealt including defense values
        private void changeStatusEffect(string status)
        {
            if (status == "")
            {
                CpuStatus.Text = "";
                CpuStatus.Visibility = Visibility.Hidden;
            }
            if (status == "Poison")
            {
                CpuStatus.Text = "PSN";
                CpuStatus.Visibility = Visibility.Visible;

                CpuStatus.Background = new SolidColorBrush(Colors.Purple);
                CpuStatus.Foreground = new SolidColorBrush(Colors.White);

            }
            else if (status == "Paralyzed")
            {
                CpuStatus.Visibility = Visibility.Visible;

                CpuStatus.Text = "PAR";
                CpuStatus.Background = new SolidColorBrush(Colors.Yellow);
                CpuStatus.Foreground = new SolidColorBrush(Colors.Black);

            }
            else if (status == "Sleep")
            {
                CpuStatus.Visibility = Visibility.Visible;

                CpuStatus.Text = "SLP";
                CpuStatus.Background = new SolidColorBrush(Colors.Magenta);
                CpuStatus.Foreground = new SolidColorBrush(Colors.White);
            }
            else if (status == "Burn")
            {
                CpuStatus.Visibility = Visibility.Visible;

                CpuStatus.Text = "BRN";
                CpuStatus.Background = new SolidColorBrush(Colors.OrangeRed);
            }

        }
        private int totalDmgDealt(int moveDmg, int pDefense, string critOrMiss, string Mtype, string enemyType, int cpAtk)
        {
            int totalDmgDealt = moveDmg - pDefense / 2 + (cpAtk / 2);
            if (totalDmgDealt <= 0)
            {
                totalDmgDealt = 0;
            }
            if (critOrMiss == "Hit")
            {
                totalDmgDealt = moveDmg - pDefense / 2 + (cpAtk / 2);
            }

            if (critOrMiss == "Missed")
            {
                totalDmgDealt = 0;

            }
            if (critOrMiss == "Crit")
            {
                totalDmgDealt *= 2;
            }


            return totalDmgDealt;
        }
        //Quits game
        public void cpuBattle()
        {
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };

            timer.Start();
            timer.Tick += (sender, args) =>
            {
                timer.Stop();
                cpuMove(critOrMis2);
                sGrid.Visibility = Visibility.Visible;
                mGrid.Visibility = Visibility.Hidden;
                gif.Visibility = Visibility.Hidden;
                checkForWin();
            };
        }
        private void btnQuit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow newGame = new MainWindow();
            newGame.Show();
            this.Close();
        }
        //Gets random move for cpu to choose
        public void userMove(int dmgDealt, string critOrMis, string currentMove)
        {
            cpuHP -= totalDmgDealt(dmgDealt, cpuDef, critOrMis, "", "", userAtk);
            Hbar_1.Value = cpuHP;
            updateCHealth();
        }
        public void battle(int dmgDealt, string critOrMis, string critOrMis2, string moveName, bool statMove, string whatStatM, string mType)
        {
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };

            switch (CpuStatus.Text)
            {
                case "":
                    if (check_Speed() == currentPokemon)
                    {

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack ";
                        userMove(dmgDealt, critOrMis, moveName);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuMove(critOrMis2);
                                txtUpdateUser.Text = game.CpuPokemon + " Attack " + critOrMis2;
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }


                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }


                    }
                    if (check_Speed() == cpuPokemon)
                    {
                        txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                        cpuMove(critOrMis2);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                userMove(dmgDealt, critOrMis, moveName);
                                txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack ";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();

                            };
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    break;
                case "PSN":
                    if (check_Speed() == currentPokemon)
                    {

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it was a " + critOrMis + " attack";
                        userMove(dmgDealt, critOrMis, moveName);
                        changeStatusEffect(cpuStatus);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuMove(critOrMis2);
                                txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Visible;
                                checkForWin();
                            };

                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuHP -= cpuMaxHP / 12;
                                Hbar_1.Value = cpuHP;
                                updateCHealth();
                                txtUpdateUser.Text = game.CpuPokemon + " was hurt by Poison";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    if (check_Speed() == cpuPokemon)
                    {
                        txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                        cpuMove(critOrMis2);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            checkForWin();
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it was a " + critOrMis + " attack";
                                userMove(dmgDealt, critOrMis, moveName);
                                checkForWin();
                                gif.Visibility = Visibility.Visible;

                            };

                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuHP -= cpuMaxHP / 12;
                                Hbar_1.Value = cpuHP;
                                updateCHealth();
                                txtUpdateUser.Text = game.CpuPokemon + " was hurt by Poison";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    break;
                case "BRN":
                    if (check_Speed() == currentPokemon)
                    {

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it was a " + critOrMis + " attack";
                        userMove(dmgDealt, critOrMis, moveName);
                        changeStatusEffect(cpuStatus);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuMove(critOrMis2);
                                txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Visible;
                                checkForWin();
                            };

                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuHP -= cpuMaxHP / 12;
                                Hbar_1.Value = cpuHP;
                                updateCHealth();
                                txtUpdateUser.Text = game.CpuPokemon + " was hurt by burn";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    if (check_Speed() == cpuPokemon)
                    {
                        txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                        cpuMove(critOrMis2);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            checkForWin();
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it was a " + critOrMis + " attack";
                                userMove(dmgDealt, critOrMis, moveName);
                                checkForWin();
                                gif.Visibility = Visibility.Visible;

                            };

                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuHP -= cpuMaxHP / 12;
                                Hbar_1.Value = cpuHP;
                                updateCHealth();
                                txtUpdateUser.Text = game.CpuPokemon + " was hurt by Burn";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    break;
                case "PAR":
                    if (check_Speed() == currentPokemon)
                    {

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack ";
                        userMove(dmgDealt, critOrMis, moveName);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {

                            if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = cpuPokemon + " cannot move due to paralysis";
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();

                                };
                            }
                            else
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    if (check_Speed() == cpuPokemon)
                    {
                        if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3 || r.Next(1, 6) == 4)
                        {
                            txtUpdateUser.Text = cpuPokemon + " couldn't move due to paralysis";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;
                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack ";
                                    userMove(dmgDealt, critOrMis, moveName);
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                    sGrid.Visibility = Visibility.Visible;
                                };

                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        } 
                        else
                        {
                            txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack ";
                                    userMove(dmgDealt, critOrMis, moveName);
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                    sGrid.Visibility = Visibility.Visible;
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                    }
                    break;
                case "SLP":
                    if (check_Speed() == currentPokemon)
                    {

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + "attack";
                        userMove(dmgDealt, critOrMis, moveName);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            if (r.Next(1, 5) == 3)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuMove(critOrMis2);
                                    CpuStatus.Text = "";
                                    cpuStatus = "";
                                    changeStatusEffect(cpuStatus);
                                
                                    txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();

                                    txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }

                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    if (check_Speed() == cpuPokemon)
                    {

                        if (r.Next(1, 5) == 3)
                        {
                            cpuMove(critOrMis2);
                            CpuStatus.Text = "";
                            cpuStatus = "";
                            changeStatusEffect(cpuStatus);
                            txtUpdateUser.Text = game.CpuPokemon + " woke up and its attack " + critOrMis2;
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Hidden;

                            checkForWin();
                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack";
                                    userMove(dmgDealt, critOrMis, moveName);
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                    sGrid.Visibility = Visibility.Visible;
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        else
                        {

                            txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Hidden;
                            checkForWin();


                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack";
                                    userMove(dmgDealt, critOrMis, moveName);
                                    checkForWin();

                                    sGrid.Visibility = Visibility.Visible;
                                    gif.Visibility = Visibility.Visible;
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                    }
                    break;
            }
        }
        public void statUpMove(int dmgDealt, string critOrMis, string critOrMis2, string moveName, string whatStat, string incDec, string targetP)
        {
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };

            switch (CpuStatus.Text)
            {
                case "":
                    if (check_Speed() == currentPokemon)
                    {

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuMove(critOrMis2);
                                txtUpdateUser.Text = game.CpuPokemon + " Attack " + critOrMis2;
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }


                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }


                    }
                    if (check_Speed() == cpuPokemon)
                    {
                        txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                        cpuMove(critOrMis2);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();

                            };
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    break;
                case "PSN":
                    if (check_Speed() == currentPokemon)
                    {

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuMove(critOrMis2);
                                txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Visible;
                                checkForWin();
                            };

                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuHP -= cpuMaxHP / 12;
                                Hbar_1.Value = cpuHP;
                                updateCHealth();
                                txtUpdateUser.Text = game.CpuPokemon + " was hurt by Poison";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    if (check_Speed() == cpuPokemon)
                    {
                        txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                        cpuMove(critOrMis2);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            checkForWin();
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                                checkForWin();
                                gif.Visibility = Visibility.Visible;

                            };

                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuHP -= cpuMaxHP / 12;
                                Hbar_1.Value = cpuHP;
                                updateCHealth();
                                txtUpdateUser.Text = game.CpuPokemon + " was hurt by Poison";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    break;
                case "BRN":
                    if (check_Speed() == currentPokemon)
                    {

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                        changeStatusEffect(cpuStatus);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuMove(critOrMis2);
                                txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Visible;
                                checkForWin();
                            };

                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuHP -= cpuMaxHP / 12;
                                Hbar_1.Value = cpuHP;
                                updateCHealth();
                                txtUpdateUser.Text = game.CpuPokemon + " was hurt by burn";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    if (check_Speed() == cpuPokemon)
                    {
                        txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                        cpuMove(critOrMis2);
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            checkForWin();
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                                checkForWin();
                                gif.Visibility = Visibility.Visible;

                            };

                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuHP -= cpuMaxHP / 12;
                                Hbar_1.Value = cpuHP;
                                updateCHealth();
                                txtUpdateUser.Text = game.CpuPokemon + " was hurt by Burn";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    break;
                case "PAR":
                    if (check_Speed() == currentPokemon)
                    {

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {

                            if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = cpuPokemon + " cannot move due to paralysis";
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();

                                };
                            }
                            else
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    if (check_Speed() == cpuPokemon)
                    {
                        if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3 || r.Next(1, 6) == 4)
                        {
                            txtUpdateUser.Text = cpuPokemon + " couldn't move due to paralysis";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;
                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                    sGrid.Visibility = Visibility.Visible;
                                };

                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        else
                        {
                            txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                    sGrid.Visibility = Visibility.Visible;
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                    }
                    break;
                case "SLP":
                    if (check_Speed() == currentPokemon)
                    {

                        txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                        checkForWin();
                        gif.Visibility = Visibility.Visible;

                        if (!won)
                        {
                            if (r.Next(1, 5) == 3)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuMove(critOrMis2);
                                    CpuStatus.Text = "";
                                    cpuStatus = "";
                                    changeStatusEffect(cpuStatus);

                                    txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();

                                    txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }

                        }
                        else if (won)
                        {
                            sGrid.Visibility = Visibility.Visible;

                        }
                    }
                    if (check_Speed() == cpuPokemon)
                    {

                        if (r.Next(1, 5) == 3)
                        {
                            cpuMove(critOrMis2);
                            CpuStatus.Text = "";
                            cpuStatus = "";
                            changeStatusEffect(cpuStatus);
                            txtUpdateUser.Text = game.CpuPokemon + " woke up and its attack " + critOrMis2;
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Hidden;

                            checkForWin();
                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + targetP + " " + whatStat + " " + incDec;
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                    sGrid.Visibility = Visibility.Visible;
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        else
                        {

                            txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Hidden;
                            checkForWin();


                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack";
                                    userMove(dmgDealt, critOrMis, moveName);
                                    checkForWin();

                                    sGrid.Visibility = Visibility.Visible;
                                    gif.Visibility = Visibility.Visible;
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                    }
                    break;
            }
        }
        public void paralysisMove(string moveName, string critOrMis, string critOrMis2, int dmgDealt)
        {
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };
            if (!hasStatus)
            {
                if (check_Speed() == currentPokemon)
                {

                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack and " + cpuPokemon + " was inflicted with paralysis";
                    userMove(dmgDealt, critOrMis, moveName);
                    checkForWin();
                    gif.Visibility = Visibility.Visible;

                    if (!won)
                    {

                        if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3)
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                txtUpdateUser.Text = cpuPokemon + " cannot move due to paralysis";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();

                            };
                        }
                        else
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();
                                cpuMove(critOrMis2);
                                txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }
                    }
                    else if (won)
                    {
                        sGrid.Visibility = Visibility.Visible;

                    }
                }
                if (check_Speed() == cpuPokemon)
                {
                    txtUpdateUser.Text = game.CpuPokemon + " attacks " + critOrMis2;
                    cpuMove(critOrMis2);
                    checkForWin();
                    gif.Visibility = Visibility.Visible;

                    if (!won)
                    {
                        timer.Start();
                        timer.Tick += (sender, args) =>
                        {
                            timer.Stop();
                            txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it was a " + critOrMis + " attack and was inflicted with paralysis";
                            userMove(dmgDealt, critOrMis, moveName);
                            checkForWin();
                            gif.Visibility = Visibility.Hidden;
                            sGrid.Visibility = Visibility.Visible;
                        };

                    }
                    else if (won)
                    {
                        sGrid.Visibility = Visibility.Visible;

                    }
                }
            }
            else if (hasStatus)
            {
                switch (cpuStatus)
                {
                    case "Poison":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " Attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Hidden;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Visible;
                                    checkForWin();
                                };

                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {
                            txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;

                                };
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by Poison" ;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;
                    case "Paralyzed":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {

                                if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3)
                                {
                                    timer.Start();
                                    timer.Tick += (sender, args) =>
                                    {
                                        timer.Stop();
                                        txtUpdateUser.Text = cpuPokemon + " cannot move due to paralysis";
                                        sGrid.Visibility = Visibility.Visible;
                                        mGrid.Visibility = Visibility.Hidden;
                                        gif.Visibility = Visibility.Hidden;
                                        checkForWin();

                                    };
                                }
                                else
                                {
                                    timer.Start();
                                    timer.Tick += (sender, args) =>
                                    {
                                        timer.Stop();
                                        cpuMove(critOrMis2);
                                        txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                        sGrid.Visibility = Visibility.Visible;
                                        mGrid.Visibility = Visibility.Hidden;
                                        gif.Visibility = Visibility.Hidden;
                                        checkForWin();
                                    };
                                }
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {
                            if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3)
                            {
                                txtUpdateUser.Text = cpuPokemon + " couldn't move due to paralysis";
                                checkForWin();
                                gif.Visibility = Visibility.Visible;
                            }
                            else
                            {
                                txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                cpuMove(critOrMis2);
                                checkForWin();
                                gif.Visibility = Visibility.Visible;
                            }
                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                    sGrid.Visibility = Visibility.Visible;
                                };

                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;
                    case "Burn":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Hidden;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Visible;
                                    checkForWin();
                                };

                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by burn";
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {
                            txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                checkForWin();
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;

                                };
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by burn";
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;
                    case "Sleep":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;


                            if (!won)
                            {
                                if (r.Next(1, 5) == 3)
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                }
                                else
                                {
                                    timer.Start();
                                    timer.Tick += (sender, args) =>
                                    {
                                        timer.Stop();

                                        txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                                        sGrid.Visibility = Visibility.Visible;
                                        mGrid.Visibility = Visibility.Hidden;
                                        gif.Visibility = Visibility.Hidden;
                                        checkForWin();
                                    };
                                }

                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {

                            if (r.Next(1, 5) == 3)
                            {
                                cpuMove(critOrMis2);
                                txtUpdateUser.Text = game.CpuPokemon + " woke up and its attack " + critOrMis2;
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            }
                            else
                            {
                                txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();

                            }
                            if (!won)
                            {

                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;

                }
            }
        }
        public void poisonBurnMove(string moveName, string critOrMis, string critOrMis2, int dmgDealt)
        {
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };
            if (!hasStatus)
            {
                if (check_Speed() == currentPokemon)
                {

                    txtUpdateUser.Text = currentPokemon + " used " + moveName + " and " + cpuPokemon + " was inflicted by " + cpuStatus;
                    userMove(dmgDealt, critOrMis, moveName);
                    changeStatusEffect(cpuStatus);
                    checkForWin();
                    gif.Visibility = Visibility.Visible;

                    if (!won)
                    {
                        timer.Start();
                        timer.Tick += (sender, args) =>
                        {
                            timer.Stop();
                            cpuMove(critOrMis2);
                            txtUpdateUser.Text = game.CpuPokemon + " Attack " + critOrMis2;
                            sGrid.Visibility = Visibility.Hidden;
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Visible;
                            checkForWin();
                        };

                        timer.Start();
                        timer.Tick += (sender, args) =>
                        {
                            cpuHP -= cpuMaxHP / 12;
                            Hbar_1.Value = cpuHP;
                            updateCHealth();
                            txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                            sGrid.Visibility = Visibility.Visible;
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Hidden;
                            checkForWin();
                        };
                    }
                    else if (won)
                    {
                        sGrid.Visibility = Visibility.Visible;

                    }
                }
                if (check_Speed() == cpuPokemon)
                {
                    txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                    cpuMove(critOrMis2);
                    checkForWin();
                    gif.Visibility = Visibility.Visible;

                    if (!won)
                    {
                        checkForWin();
                        timer.Start();
                        timer.Tick += (sender, args) =>
                        {
                            timer.Stop();
                            txtUpdateUser.Text = currentPokemon + " used " + moveName + " and " + cpuPokemon + " was inflicted by " + cpuStatus;
                            changeStatusEffect(cpuStatus);
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                        };
                        timer.Start();
                        timer.Tick += (sender, args) =>
                        {
                            cpuHP -= cpuMaxHP / 12;
                            Hbar_1.Value = cpuHP;
                            updateCHealth();
                            txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                            sGrid.Visibility = Visibility.Visible;
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Hidden;
                            checkForWin();
                        };
                    }
                    else if (won)
                    {
                        sGrid.Visibility = Visibility.Visible;

                    }
                }

            }
            else if (hasStatus)
            {
                switch (cpuStatus)
                {
                    case "Poison":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " Attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Hidden;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Visible;
                                    checkForWin();
                                };

                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {
                            txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                checkForWin();
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;

                                };
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;
                    case "Paralyzed":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {

                                if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3)
                                {
                                    timer.Start();
                                    timer.Tick += (sender, args) =>
                                    {
                                        timer.Stop();
                                        txtUpdateUser.Text = cpuPokemon + " cannot move due to paralysis";
                                        sGrid.Visibility = Visibility.Visible;
                                        mGrid.Visibility = Visibility.Hidden;
                                        gif.Visibility = Visibility.Hidden;
                                        checkForWin();

                                    };
                                }
                                else
                                {
                                    timer.Start();
                                    timer.Tick += (sender, args) =>
                                    {
                                        timer.Stop();
                                        cpuMove(critOrMis2);
                                        txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                        sGrid.Visibility = Visibility.Visible;
                                        mGrid.Visibility = Visibility.Hidden;
                                        gif.Visibility = Visibility.Hidden;
                                        checkForWin();
                                    };
                                }
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {
                            if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3)
                            {
                                txtUpdateUser.Text = cpuPokemon + " couldn't move due to paralysis";
                                checkForWin();
                                gif.Visibility = Visibility.Visible;
                            }
                            else
                            {
                                txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                cpuMove(critOrMis2);
                                checkForWin();
                                gif.Visibility = Visibility.Visible;
                            }
                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                    sGrid.Visibility = Visibility.Visible;
                                };

                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;
                    case "Burn":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " Attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Hidden;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Visible;
                                    checkForWin();
                                };

                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {
                            txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                checkForWin();
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;

                                };
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;
                    case "Sleep":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;


                            if (!won)
                            {
                                if (r.Next(1, 5) == 3)
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                }
                                else
                                {
                                    timer.Start();
                                    timer.Tick += (sender, args) =>
                                    {
                                        timer.Stop();

                                        txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                                        sGrid.Visibility = Visibility.Visible;
                                        mGrid.Visibility = Visibility.Hidden;
                                        gif.Visibility = Visibility.Hidden;
                                        checkForWin();
                                    };
                                }

                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {

                            if (r.Next(1, 5) == 3)
                            {
                                cpuMove(critOrMis2);
                                txtUpdateUser.Text = game.CpuPokemon + " woke up and its attack " + critOrMis2;
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            }
                            else
                            {
                                txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();

                            }
                            if (!won)
                            {

                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;

                }
            }
        }
        public void sleepMove(string moveName, string critOrMis, string critOrMis2, int dmgDealt)
        {
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };
            if (!hasStatus)
            {
                if (check_Speed() == currentPokemon)
                {

                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and " + cpuPokemon + " fell asleep";
                    changeStatusEffect(cpuStatus);
                    checkForWin();
                    gif.Visibility = Visibility.Visible;


                    if (!won)
                    {
                        if (r.Next(1, 5) == 3)
                        {
                            timer.Stop();
                            cpuStatus = "";
                            changeStatusEffect(cpuStatus);
                            cpuMove(critOrMis2);
                            txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                            sGrid.Visibility = Visibility.Visible;
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Hidden;
                            checkForWin();
                        }
                        else
                        {
                            timer.Start();
                            timer.Tick += (sender, args) =>
                            {
                                timer.Stop();

                                txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            };
                        }

                    }
                    else if (won)
                    {
                        sGrid.Visibility = Visibility.Visible;

                    }
                }
                if (check_Speed() == cpuPokemon)
                {

                    txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                    cpuMove(critOrMis2);
                    checkForWin();
                    gif.Visibility = Visibility.Visible;

                    if (!won)
                    {
                        timer.Tick += (sender, args) =>
                        {
                            timer.Stop();
                            txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack and " + cpuPokemon + " fell asleep";
                            changeStatusEffect(cpuStatus);
                            userMove(dmgDealt, critOrMis, moveName);
                            checkForWin();
                            gif.Visibility = Visibility.Visible;
                        };
                    }
                    else if (won)
                    {
                        sGrid.Visibility = Visibility.Visible;

                    }
                }
            }
            else if (hasStatus)
            {
                switch (cpuStatus)
                {
                    case "Poison":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " Attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Hidden;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Visible;
                                    checkForWin();
                                };

                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {
                            txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                checkForWin();
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;

                                };
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;
                    case "Paralysed":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {

                                if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3)
                                {
                                    timer.Start();
                                    timer.Tick += (sender, args) =>
                                    {
                                        timer.Stop();
                                        txtUpdateUser.Text = cpuPokemon + " cannot move due to paralysis";
                                        sGrid.Visibility = Visibility.Visible;
                                        mGrid.Visibility = Visibility.Hidden;
                                        gif.Visibility = Visibility.Hidden;
                                        checkForWin();

                                    };
                                }
                                else
                                {
                                    timer.Start();
                                    timer.Tick += (sender, args) =>
                                    {
                                        timer.Stop();
                                        cpuMove(critOrMis2);
                                        txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                        sGrid.Visibility = Visibility.Visible;
                                        mGrid.Visibility = Visibility.Hidden;
                                        gif.Visibility = Visibility.Hidden;
                                        checkForWin();
                                    };
                                }
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {
                            if (r.Next(1, 6) == 2 || r.Next(1, 6) == 3)
                            {
                                txtUpdateUser.Text = cpuPokemon + " couldn't move due to paralysis";
                                checkForWin();
                                gif.Visibility = Visibility.Visible;
                            }
                            else
                            {
                                txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                cpuMove(critOrMis2);
                                checkForWin();
                                gif.Visibility = Visibility.Visible;
                            }
                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                    sGrid.Visibility = Visibility.Visible;
                                };

                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;
                    case "Burn":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " Attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Hidden;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Visible;
                                    checkForWin();
                                };

                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {
                            txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            checkForWin();
                            gif.Visibility = Visibility.Visible;

                            if (!won)
                            {
                                checkForWin();
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + " and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;

                                };
                                timer.Start();
                                timer.Tick += (sender, args) =>
                                {
                                    cpuHP -= cpuMaxHP / 12;
                                    Hbar_1.Value = cpuHP;
                                    updateCHealth();
                                    txtUpdateUser.Text = game.CpuPokemon + " was hurt by " + cpuStatus;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;
                    case "Sleep":
                        if (check_Speed() == currentPokemon)
                        {

                            txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it failed";
                            checkForWin();
                            gif.Visibility = Visibility.Visible;


                            if (!won)
                            {
                                if (r.Next(1, 5) == 3)
                                {
                                    timer.Stop();
                                    cpuMove(critOrMis2);
                                    txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                                    sGrid.Visibility = Visibility.Visible;
                                    mGrid.Visibility = Visibility.Hidden;
                                    gif.Visibility = Visibility.Hidden;
                                    checkForWin();
                                }
                                else
                                {
                                    timer.Start();
                                    timer.Tick += (sender, args) =>
                                    {
                                        timer.Stop();

                                        txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                                        sGrid.Visibility = Visibility.Visible;
                                        mGrid.Visibility = Visibility.Hidden;
                                        gif.Visibility = Visibility.Hidden;
                                        checkForWin();
                                    };
                                }

                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        if (check_Speed() == cpuPokemon)
                        {

                            if (r.Next(1, 5) == 3)
                            {
                                cpuMove(critOrMis2);
                                txtUpdateUser.Text = game.CpuPokemon + " woke up and its attack " + critOrMis2;
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();
                            }
                            else
                            {
                                txtUpdateUser.Text = cpuPokemon + " is fast asleep ";
                                sGrid.Visibility = Visibility.Visible;
                                mGrid.Visibility = Visibility.Hidden;
                                gif.Visibility = Visibility.Hidden;
                                checkForWin();

                            }
                            if (!won)
                            {

                                timer.Tick += (sender, args) =>
                                {
                                    timer.Stop();
                                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it failed";
                                    checkForWin();
                                    gif.Visibility = Visibility.Visible;
                                };
                            }
                            else if (won)
                            {
                                sGrid.Visibility = Visibility.Visible;

                            }
                        }
                        break;

                }
            }

        }
        //This is to check move dmg and using total dmg dealt deals dmg (Want to add speed stats to see who goes first)
        private void btnMove_click(object sender, RoutedEventArgs e)
        {
            string currentMove = (sender as Button).Content.ToString();

            string critOrMis = critOrMiss();
            string critOrMis2 = critOrMiss();
            int dmgDealt;
            int i = 0;
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };


            switch (currentMove)
            {
                case "Growth":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 0;
                    int aa = 0;
                    if (aa < 6)
                    {
                        userAtk += 10;
                    }
                    statUpMove(dmgDealt, critOrMis, critOrMis2, currentMove, "attack", "increased", currentPokemon);
                    break;
                case "Stun Spore":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 0;
                    if (hasStatus == false)
                    { 
                        cpuStatus = "Paralyzed";
                        changeStatusEffect(cpuStatus);
                        paralysisMove("Stun Spore", critOrMis, critOrMis2, dmgDealt);
                        hasStatus = true;
                    }else
                    {
                        paralysisMove("Stun Spore", critOrMis, critOrMis2, dmgDealt);
                    }
                    break;
                case "Giga Drain":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 75;
                    if (critOrMis == "Miss")
                    {
                        CurrentUserHP += 25;
                        Hbar_2.Value = CurrentUserHP;
                        updateCHealth();

                    }
                    else if (critOrMis == "Crit")
                    {
                        CurrentUserHP += 40;
                        Hbar_2.Value = CurrentUserHP;
                        updateCHealth();

                    }
                    else
                    {
                        CurrentUserHP += 20;
                        Hbar_2.Value = CurrentUserHP;
                        updateCHealth();


                    }
                    battle(dmgDealt, critOrMis, critOrMis2, "Giga Drain ", true, "", "Grass");
                    break;
                case "Poison Powder":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 0;
                    if (hasStatus == false)
                    {
                        cpuStatus = "Poison";
                        changeStatusEffect(cpuStatus);
                        poisonBurnMove("Poison Powder", critOrMis, critOrMis2, dmgDealt);
                        hasStatus = true;
                    }else
                    {
                        poisonBurnMove("Poison Powder", critOrMis, critOrMis2, dmgDealt);
                    }

                    break;
                case "Growl":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 0;
                    int a = 0;

                    if (a < 6)
                    {
                        cpuAtk -= 10;
                    }

                    statUpMove(dmgDealt, critOrMis, critOrMis2, currentMove, "attack", "decreased", cpuPokemon);

                    break;
                case "Lava Plume":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 100;
                    battle(dmgDealt, critOrMis, critOrMis2, "Lava Plume ", false, "", "Fire");
                    break;
                case "Fire Fang":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 75;
                    if (hasStatus == false)
                    {
                        if (r.Next(1, 10) == 1)
                        {
                            cpuStatus = "Burn";
                            changeStatusEffect(cpuStatus);
                            poisonBurnMove("Fire Fang", critOrMis, critOrMis2, dmgDealt);
                            hasStatus = true;
                        }
                        else
                        {
                            poisonBurnMove("Fire Fang", critOrMis, critOrMis2, dmgDealt);
                        }
                    }
                    battle(dmgDealt, critOrMis, critOrMis2, "Fire fang", false, "", "Fire");
                    break;
                case "Tri Attack":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 80;
                    battle(dmgDealt, critOrMis, critOrMis2, "Tri Attack ", false, "", "Normal");
                    break;
                case "Hyper Beam":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 100;
                    battle(dmgDealt, critOrMis, critOrMis2, "Hyper Beam ", false, "", "Normal");
                    break;
                case "Dragon Breath":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 60;
                    battle(dmgDealt, critOrMis, critOrMis2, "Dragon Breath ", false, "", "Dragon");
                    break;
                case "Bite":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 75;
                    battle(dmgDealt, critOrMis, critOrMis2, "Bite ", false, "", "Dark");
                    break;
                case "Confusion":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 90;
                    battle(dmgDealt, critOrMis, critOrMis2, "Confusion ", false, "", "Psychic");
                    break;
                case "Psych Up":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 0;
                    int h = 0;
                    h += 1;
                    if (h < 6)
                    {
                        userAtk += 6;
                    }
                    statUpMove(dmgDealt, critOrMis, critOrMis2, currentMove, "attack", "increased", currentPokemon);
                    break;
                case "Zen Headbutt":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 80;
                    battle(dmgDealt, critOrMis, critOrMis2, "Zen Headbutt ", false, "", "Psychic");
                    break;
                case "Yawn":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 0;
                    if (hasStatus == false)
                    {
                        cpuStatus = "Sleep";
                        hasStatus = true;
                        changeStatusEffect(cpuStatus);
                        sleepMove("Yawn", critOrMis, critOrMis2, dmgDealt);
                    }
                    else
                    {
                        sleepMove("Yawn", critOrMis, critOrMis2, dmgDealt);
                    }
                    break;
                case "Lick":
                    mGrid.Visibility = Visibility.Hidden;
                    int rInt = r.Next(1, 10);
                    if (hasStatus == false)
                    {
                        if (rInt == 5)
                        {
                            cpuStatus = "Paralyzed";
                            changeStatusEffect(cpuStatus);
                            paralysisMove("Lick", critOrMis, critOrMis2, 20);
                            hasStatus = true;
                        }
                        else
                        {
                            paralysisMove("Lick", critOrMis, critOrMis2, 20);
                        }
                    }
                    break;
                case "Defense Curl":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 0;
                    int l = 0;
                    l += 1;
                    if (l < 6)
                    {
                        userDef += 5;
                    }
                    statUpMove(dmgDealt, critOrMis, critOrMis2, currentMove, "defense", "increased", currentPokemon);
                    break;
                case "Leer":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 0;
                    int k = 0;
                    k += 1;
                    if (k < 6)
                    {
                        cpuDef -= 5;
                    }
                    statUpMove(dmgDealt, critOrMis, critOrMis2, currentMove, "defense", "decreased", cpuPokemon);
                    break;
                case "Sword Dance":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 0;
                    int j = 0;
                    j += 1;

                    if (j < 6)
                    {
                        userAtk += 10;

                    }
                    statUpMove(dmgDealt, critOrMis, critOrMis2, currentMove, "attack", "increased", currentPokemon);
                    break;
                case "Drill Peck":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 60;
                    battle(dmgDealt, critOrMis, critOrMis2, "Drill Peck ", false, "", "Flying");
                    break;
                case "Thunderbolt":
                    mGrid.Visibility = Visibility.Hidden;
                    dmgDealt = 75;
                    battle(dmgDealt, critOrMis, critOrMis2, "Thunderbolt ", false, "", "Electric");
                    break;
                case "Thunder Wave":
                    dmgDealt = 0;
                    if (hasStatus == false)
                    {
                        cpuStatus = "Paralyzed";
                        changeStatusEffect(cpuStatus);
                        paralysisMove("Thunder Wave", critOrMis, critOrMis2, dmgDealt);
                        hasStatus = true;
                    }
                    else
                    {
                        paralysisMove("Thunder Wave", critOrMis, critOrMis2, dmgDealt);
                    }
                    mGrid.Visibility = Visibility.Hidden;
                    break;
                case "Quick Attack":
                    int previousSpeed = userSpeed;

                    userSpeed = 5000;
                    dmgDealt = 45;
                    mGrid.Visibility = Visibility.Hidden;

                    if (check_Speed() == currentPokemon)
                    {
                        cpuHP -= totalDmgDealt(dmgDealt, cpuDef, critOrMis, "Normal", cpuType, userAtk);
                        Hbar_1.Value = cpuHP;
                        updateCHealth();
                        txtUpdateUser.Text = currentPokemon + " used quick attack and it was a " + critOrMis + " attack and it was " + effectiveNess;
                        gif.Visibility = Visibility.Visible;
                        timer.Start();
                        timer.Tick += (sender, args) =>
                        {
                            timer.Stop();
                            txtUpdateUser.Text = cpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            userSpeed = previousSpeed;
                            sGrid.Visibility = Visibility.Visible;
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Hidden;
                            checkForWin();
                        };
                    }
                    break;
                case "Earthquake":
                    dmgDealt = 80;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Earthquake ", false, "", "Ground");
                    break;
                case "Iron Tail":
                    dmgDealt = 40;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Iron Tail ", false, "", "Iron");
                    break;
                case "Dragon Claw":
                    dmgDealt = 65;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Dragon Claw ", false, "", "Dragon");
                    break;
                case "Dragon Dance":
                    dmgDealt = 0;
                    int t = 0;
                    t += 1;
                    if (t < 6)
                    {
                        userAtk += 5;
                    }
                    mGrid.Visibility = Visibility.Hidden;
                    statUpMove(dmgDealt, critOrMis, critOrMis2, currentMove, "attack", "increased", currentPokemon);
                    break;
                case "Draco Meteor":
                    dmgDealt = 100;
                    mGrid.Visibility = Visibility.Hidden;
                    userAtk -= 20;
                    battle(dmgDealt, critOrMis, critOrMis2, "Draco Meteor ", false, "", "Dragon");
                    break;
                case "Shadow Claw":
                    dmgDealt = 60;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Shadow Claw ", false, "", "Dark");
                    break;
                case "Persuit":
                    dmgDealt = 50;
                    if (userSpeed > cpuSpeed) { dmgDealt = 100; }
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Persuit ", false, "", "Dark");
                    break;
                case "Hex":
                    dmgDealt = cpuMaxHP / 3;
                    Hbar_2.Value = Hbar_2.Maximum / 2;
                    updateCHealth();
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Hex ", false, "", "Ghost");
                    break;
                case "Shadow Ball":
                    dmgDealt = 40;
                    if (i >= 1) { dmgDealt = dmgDealt * i; }
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Shadow Ball ", false, "", "Ghost");
                    break;
                case "Leaf Tornado":
                    dmgDealt = 80;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Leaf Tornado ", false, "", "Grass");
                    break;
                case "Vine Whip":
                    dmgDealt = 50;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Vine Whip ", false, "", "Grass");
                    break;

                case "Dirty Water":
                    dmgDealt = 100;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Dirty Water ", false, "", "Water");
                    break;
                case "Surf":
                    dmgDealt = 90;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Surf ", false, "", "Water");
                    break;
                case "Take Down":
                    dmgDealt = 80;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Take Down ", false, "", "Normal");
                    break;
                case "Hydro Pump":
                    dmgDealt = 90;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Hydro Pump ", false, "", "Water");
                    break;
                case "Agility":
                    dmgDealt = 0;
                    int p = 0;
                    p += 1;
                    if (p < 6)
                    {
                        userSpeed += 10;
                    }
                    statUpMove(dmgDealt, critOrMis, critOrMis2, currentMove, "speed", "increased", currentPokemon);
                    break;
            }
        }
        private string check_Speed()
        {

            string whoFirst = "";
            if (cpuStatus == "Paralyzed")
            {

                whoFirst = currentPokemon;
            }
            else if (cpuSpeed == userSpeed)
            {
                cpuPokemon = cpuPokemon + "1";
                whoFirst = currentPokemon;
            }
            else if (cpuSpeed > userSpeed)
            {
                whoFirst = cpuPokemon;
            }
            else if (userSpeed > cpuSpeed)
            {
                whoFirst = currentPokemon;
            }


            return whoFirst;
        }
        //Checks to see if someone won
        private void checkForWin()
        {

            if (Hbar_1.Value <= 0)
            {
                imgCpuP.Visibility = Visibility.Hidden;
                imgCpuS.Visibility = Visibility.Hidden;
                imgCpuSn.Visibility = Visibility.Hidden;
                imgCpuGen.Visibility = Visibility.Hidden;
                imgCpuG.Visibility = Visibility.Hidden;

                btnFight.Visibility = Visibility.Hidden;
                btnSwitch.Visibility = Visibility.Hidden;
                btnBag.Visibility = Visibility.Hidden;
                btnQuit.Visibility = Visibility.Visible;
                fightBorder.Visibility = Visibility.Hidden;
                pBorder.Visibility = Visibility.Hidden;
                bagBorder.Visibility = Visibility.Hidden;
                updateCHealth();

                txtUpdateUser.Text = game.CpuPokemon + " has fainted the winner is " + game.PlayerName;
                won = true;
            }
            else if (Hbar_2.Value <= 0)
            {
                imgUserP.Visibility = Visibility.Hidden;
                imgUserS.Visibility = Visibility.Hidden;
                imgUserSn.Visibility = Visibility.Hidden;
                imgUserGen.Visibility = Visibility.Hidden;
                imgUserG.Visibility = Visibility.Hidden;

                btnFight.Visibility = Visibility.Hidden;
                fightBorder.Visibility = Visibility.Hidden;
                pBorder.Visibility = Visibility.Hidden;
                bagBorder.Visibility = Visibility.Hidden;
                btnSwitch.Visibility = Visibility.Hidden;
                btnBag.Visibility = Visibility.Hidden;
                btnQuit.Visibility = Visibility.Visible;
                updateCHealth();
                txtUpdateUser.Text = game.UserPokemon + " has fainted the winner is CPU";
                won = true;
            }
            else if (Hbar_1.Value <= 0 && Hbar_2.Value <= 0)
            {
                imgCpuP.Visibility = Visibility.Hidden;
                imgCpuS.Visibility = Visibility.Hidden;
                imgCpuSn.Visibility = Visibility.Hidden;
                imgCpuGen.Visibility = Visibility.Hidden;
                imgCpuG.Visibility = Visibility.Hidden;

                imgUserP.Visibility = Visibility.Hidden;
                imgUserS.Visibility = Visibility.Hidden;
                imgUserSn.Visibility = Visibility.Hidden;
                imgUserGen.Visibility = Visibility.Hidden;
                imgUserG.Visibility = Visibility.Hidden;

                btnFight.Visibility = Visibility.Hidden;
                btnSwitch.Visibility = Visibility.Hidden;
                btnBag.Visibility = Visibility.Hidden;
                btnQuit.Visibility = Visibility.Visible;
                fightBorder.Visibility = Visibility.Hidden;
                pBorder.Visibility = Visibility.Hidden;
                bagBorder.Visibility = Visibility.Hidden;

                updateCHealth();
                txtUpdateUser.Text = "Game Was tied";
            }


        }

    }
}
