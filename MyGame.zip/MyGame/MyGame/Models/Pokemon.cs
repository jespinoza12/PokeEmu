﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Models
{
    public abstract class Pokemon
    {
        public int hp { get; set; }
        public int attack { get; set; }
        public int defense { get; set; }
        public int speed { get; set; }
        public string Name
        {
            get;
            set;
        }

        public Pokemon() { }


        public Pokemon(string name, int hp, int attack, int defense, int speed)
        {
            this.Name = name;
            this.hp = hp;
            this.attack = attack;
            this.defense = defense;
            this.speed = speed;
        }

    }
    class Electric : Pokemon
    {
        private string weakness;

        public Electric(string name, int hp, int attack, int defense, int speed, string weakness)
        {
            this.Name = name;
            this.hp = hp;
            this.attack = attack;
            this.defense = defense;
            this.speed = speed;
            this.weakness = weakness;
        }
    }
    class Dark : Pokemon
    {
        private string weakness;
        public Dark(string name, int hp, int attack, int defense, int speed, string weakness)
        {
            this.Name = name;
            this.hp = hp;
            this.attack = attack;
            this.defense = defense;
            this.speed = speed;
            this.weakness = weakness;
        }
    }
    class Dragon : Pokemon
    {
        private string weakness;
        public Dragon(string name, int hp, int attack, int defense, int speed, string weakness)
        {
            this.Name = name;
            this.hp = hp;
            this.attack = attack;
            this.defense = defense;
            this.speed = speed;
            this.weakness = weakness;
        }

    }
    class Water : Pokemon
    {
        private string weakness;
        public Water(string name, int hp, int attack, int defense, int speed, string weakness)
        {
            this.Name = name;
            this.hp = hp;
            this.attack = attack;
            this.defense = defense;
            this.speed = speed;
            this.weakness = weakness;
        }
    }
    class Grass : Pokemon
    {
        private string weakness;
        public Grass(string name, int hp, int attack, int defense, int speed, string weakness)
        {
            this.Name = name;
            this.hp = hp;
            this.attack = attack;
            this.defense = defense;
            this.speed = speed;
            this.weakness = weakness;
        }
    }
}
