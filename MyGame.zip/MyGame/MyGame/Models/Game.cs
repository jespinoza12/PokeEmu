﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Models
{
    public class Game : INotifyPropertyChanged
    {
        public Game()
        {
            this.UserPokemon = "Pikachu";
            this.CpuPokemon = "Gengar";
        }

        public Game(string playerName)
        {
            this.PlayerName = playerName;
            this.CpuPokemon = cpuPokemon;
            this.UserPokemon = userPokemon;

        }

        private string cpuPokemon;
        private string playerName;
        private string userPokemon;

        public string PlayerName
        {
            get { return playerName; }
            set
            {
                playerName = value;
                OnPropertyChanged("PlayerName");
            }
        }

        public string UserPokemon
        {
            get { return userPokemon; }
            set
            {
                userPokemon = value;
                OnPropertyChanged("UserPokemon");
            }

        }

        public string CpuPokemon
        {
            get { return cpuPokemon; }
            set
            {
                cpuPokemon = value;
                OnPropertyChanged("CpuPokemon");
            }
        }

        #region INotifiyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
    }
}
