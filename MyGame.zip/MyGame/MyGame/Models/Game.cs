﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Models
{
    public class Game : INotifyPropertyChanged
    {
        public Game()
        {
            
        }

        public Game(string playerName)
        {
            this.PlayerName = playerName;
            this.CpuPokemon = cpuPokemon;
            this.UserPokemon = userPokemon;
        }

        private int pCount;
        private int sCount;
        private int hCount;

        private string cpuPokemon;
        private string playerName;
        private string userPokemon;

        public string PlayerName
        {
            get { return playerName; }
            set
            {
                playerName = value;
                OnPropertyChanged("PlayerName");
            }
        }
        public int Pcount
        {
            get { return pCount; }
            set
            {
                pCount = value;
                OnPropertyChanged("PlayerName");
            }
        }
        public int Scount
        {
            get { return sCount; }
            set
            {
                sCount = value;
                OnPropertyChanged("PlayerName");
            }
        }
        public int Hcount
        {
            get { return hCount; }
            set
            {
                hCount = value;
                OnPropertyChanged("PlayerName");
            }
        }
        

        public string UserPokemon
        {
            get { return userPokemon; }
            set
            {
                userPokemon = value;
                OnPropertyChanged("UserPokemon");
            }

        }

        public string CpuPokemon
        {
            get { return cpuPokemon; }
            set
            {
                cpuPokemon = value;
                OnPropertyChanged("CpuPokemon");
            }
        }
        

        #region INotifiyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
    }
}
