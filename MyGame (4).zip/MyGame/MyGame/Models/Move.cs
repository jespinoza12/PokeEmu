﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Models
{
    public class Move
    {
        public string type;
        public string name { get; set; }
        public int moveSlot { get; set; }
        public int damage { get; set; }

        public Move(int slot, int damage, string type)
        {
            this.type = type;
            this.moveSlot = slot;
            this.damage = damage;
        }
    }

    class moveComparer : IComparer<Move>
    {
        public int Compare(Move x, Move y)
        {
            return x.damage.CompareTo(y.damage);
        }

    }

}



