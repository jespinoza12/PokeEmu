﻿using MyGame.Models;
using MyGame.ViewModels;
using MyGame.Views;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace MyGame
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {

        public Game game;
        //Global Stat usage

        int cpuHP;
        int CurrentUserHP;
        int cpuSpeed;
        int userSpeed;
        int cpuDef;
        int userDef;
        int pokeHp;
        int cpuMaxHP;
        string cpuType;
        string userType;
        Random r = new Random();
        //Current Pokemon
        string currentPokemon;
        string cpuPokemon;
        bool moved;
        Pokemon pikachu = new Electric("Pikachu", 180, 103, 76, 166, "Ground");
        Pokemon gengar = new Dark("Gengar", 230, 121, 112, 202, "Ground/Ghost/Psychic/Dark");
        Pokemon garchomp = new Dragon("Garchomp", 215, 200, 161, 150, "Dragon/Ice");
        Pokemon Swampert = new Water("Swampert", 177, 125, 90, 130, "Grass");
        Pokemon Snivy = new Grass("Snivy", 150, 125, 100, 117, "Fire");
        string effectiveNess;
        private int cpuAtk;
        private int userAtk;


        public MainWindow()
        {
            InitializeComponent();
            game = new Game();


            //setup for GameSettings dialog. Event called when its updated.
            GameSettings settings = new GameSettings(game);

            //Show settings, and wait for it to complete. 
            settings.ShowDialog();

            //set dataContext to Game
            DataContext = game;

            gameStart();

        }
        private void btnBag_Click(object sender, RoutedEventArgs e)
        {
            Bag bag = new Bag();
            bag.Show();
        }
        public void potionRestore()
        {

            if (CurrentUserHP >= Hbar_2.Maximum)
            {
                txtUpdateUser.Text = "Pikachu's HP is already full.";
            }
            else if (CurrentUserHP != 0)
            {
                CurrentUserHP += 20;

                if (CurrentUserHP > Hbar_2.Maximum)
                {
                    int max = (int)Hbar_2.Maximum;
                    CurrentUserHP = max;
                    Hbar_2.Value = CurrentUserHP;
                    updateCHealth();
                    txtUpdateUser.Text = "Pikachu's HP was restored by 20 points.";
                }

                else
                {
                    Hbar_2.Value = CurrentUserHP;
                    updateCHealth();
                    txtUpdateUser.Text = "Pikachu's HP was restored by 20 points.";
                }
            }
        }

        //Restores Pokemon's HP by 50
        public void superPotionRestore()
        {
            if (CurrentUserHP >= Hbar_2.Maximum)
            {
                txtUpdateUser.Text = "Pikachu's HP is already full.";
            }
            else if (CurrentUserHP != 0)
            {
                CurrentUserHP += 50;

                if (CurrentUserHP > Hbar_2.Maximum)
                {
                    int max = (int)Hbar_2.Maximum;
                    CurrentUserHP = max;
                    Hbar_2.Value = CurrentUserHP;
                    updateCHealth();
                    txtUpdateUser.Text = "Pikachu's HP was restored by 50 points.";
                }

                else
                {
                    Hbar_2.Value = CurrentUserHP;
                    updateCHealth();
                    txtUpdateUser.Text = "Pikachu's HP was restored by 50 points.";
                }
            }
        }

        //Restores Pokemon's HP by 50
        public void hyperPotionRestore()
        {
            if (CurrentUserHP == Hbar_2.Maximum)
            {
                txtUpdateUser.Text = currentPokemon + "'s HP is already full.";
            }
            else if (CurrentUserHP != 0)
            {
                CurrentUserHP += 120;

                if (CurrentUserHP > Hbar_2.Maximum)
                {
                    int max = (int)Hbar_2.Maximum;
                    CurrentUserHP = max;
                    Hbar_2.Value = CurrentUserHP;
                    updateCHealth();
                    txtUpdateUser.Text = currentPokemon + "'s HP was restored by 120 points.";
                }

                else
                {
                    Hbar_2.Value = CurrentUserHP;
                    updateCHealth();
                    txtUpdateUser.Text = currentPokemon + "'s HP was restored by 120 points.";
                }
            }
        }

        private void cpuMove(string critOrMis)
        {
            Move firstMove = new Move(1, 45, "Water");
            Move secondMove = new Move(2, 55, "Water");
            Move thirdMove = new Move(3, 65, "Water");
            Move fourthMove = new Move(4, 60, "Water");
            int[] weightedMoves = new int[10];
            ArrayList availableArraySpots = new ArrayList();
            for (int i = 0; i < 10; i++)
            {
                availableArraySpots.Add(i);
            }


            if (cpuPokemon == "Pikachu")
            {
                firstMove.type = "Electric";
                secondMove.type = "Electric";
                thirdMove.type = "Normal";
                thirdMove.type = "Steel";
            }
            if (cpuPokemon == "Gengar")
            {
                firstMove.type = "Dark";
                secondMove.type = "Dark";
                thirdMove.type = "Ghost";
                fourthMove.type = "Ghost";
            }
            if (cpuPokemon == "Garchomp")
            {
                firstMove.type = "Ground";
                secondMove.type = "Dragon";
                thirdMove.type = "Dragon";
                fourthMove.type = "Dragon";
            }
            if (cpuPokemon == "Snivy")
            {
                firstMove.type = "Grass";
                secondMove.type = "Grass";
                thirdMove.type = "Normal";
                fourthMove.type = "Normal";
            }
            if (cpuPokemon == "Swampert")
            {
                firstMove.type = "Water";
                secondMove.type = "Water";
                thirdMove.type = "Normal";
                fourthMove.type = "Water";
            }




            Move[] availableMoves = { firstMove, secondMove, thirdMove, fourthMove };
            Array.Sort(availableMoves, new moveComparer());

            while (availableArraySpots.Count > 0)
            {

                int listSpot;

                int highValue = 5;
                int medValue = 3;
                int lowValue = 1;

                for (int i = 0; i < lowValue; i++)
                {
                    listSpot = r.Next(availableArraySpots.Count);
                    int e = (int)availableArraySpots[listSpot];
                    weightedMoves[e] = availableMoves[0].moveSlot;
                    availableArraySpots.RemoveAt(listSpot);
                }

                for (int i = 0; i < lowValue; i++)
                {
                    listSpot = r.Next(availableArraySpots.Count);
                    int e = (int)availableArraySpots[listSpot];
                    weightedMoves[e] = availableMoves[1].moveSlot;
                    availableArraySpots.RemoveAt(listSpot);
                }
                for (int i = 0; i < medValue; i++)
                {
                    listSpot = r.Next(availableArraySpots.Count);
                    int e = (int)availableArraySpots[listSpot];
                    weightedMoves[e] = availableMoves[2].moveSlot;
                    availableArraySpots.RemoveAt(listSpot);
                }

                for (int i = 0; i < highValue; i++)
                {
                    listSpot = r.Next(availableArraySpots.Count);
                    int e = (int)availableArraySpots[listSpot];
                    weightedMoves[e] = availableMoves[3].moveSlot;
                    availableArraySpots.RemoveAt(listSpot);
                }

            }

            int whichMove = weightedMoves[r.Next(weightedMoves.Length)];
            int random = r.Next(3);

            if (whichMove == 1)
            {
                CurrentUserHP -= totalDmgDealt(firstMove.damage, userDef, critOrMis, firstMove.type, userType);
                Hbar_2.Value = CurrentUserHP;
                updateCHealth();

            }
            if (whichMove == 2)
            {
                CurrentUserHP -= totalDmgDealt(secondMove.damage, userDef, critOrMis, secondMove.type, userType);
                Hbar_2.Value = CurrentUserHP;
                updateCHealth();
            }
            if (whichMove == 3)
            {
                CurrentUserHP -= totalDmgDealt(thirdMove.damage, userDef, critOrMis, thirdMove.type, userType);
                Hbar_2.Value = CurrentUserHP;

                updateCHealth();
            }
            if (whichMove == 4)
            {
                CurrentUserHP -= totalDmgDealt(fourthMove.damage, userDef, critOrMis, fourthMove.type, userType);

                Hbar_2.Value = CurrentUserHP;

                updateCHealth();
            }

            //txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis;

        }
        public int Maximum { get; set; }

        public void changeDefaultPokemon(string cpuPokemon, string userPokemon)
        {


            if (cpuPokemon == "Gengar") { cpuHP = gengar.hp; cpuSpeed = gengar.speed; cpuDef = gengar.defense; cpuPN.Text = gengar.Name; cpuAtk = gengar.attack; imgCpuGen.Visibility = Visibility.Visible; cpuMaxHP = gengar.hp; cpuType = "Ghost"; }
            if (cpuPokemon == "Garchomp") { cpuHP = garchomp.hp; cpuSpeed = garchomp.speed; cpuDef = garchomp.defense; cpuPN.Text = garchomp.Name; cpuAtk = garchomp.attack; imgCpuG.Visibility = Visibility.Visible; cpuMaxHP = garchomp.hp; cpuType = "Dragon"; }
            if (cpuPokemon == "Pikachu") { cpuHP = pikachu.hp; cpuSpeed = pikachu.speed; cpuDef = pikachu.defense; cpuPN.Text = pikachu.Name; cpuAtk = pikachu.attack; imgCpuP.Visibility = Visibility.Visible; cpuMaxHP = pikachu.hp; cpuType = "Electric"; }
            if (cpuPokemon == "Snivy") { cpuHP = Snivy.hp; cpuSpeed = Snivy.speed; cpuDef = Snivy.defense; cpuPN.Text = Snivy.Name; cpuAtk = Snivy.attack; imgCpuSn.Visibility = Visibility.Visible; cpuMaxHP = Snivy.hp; cpuType = "Grass"; }
            if (cpuPokemon == "Swampert") { cpuHP = Swampert.hp; cpuSpeed = Swampert.speed; cpuDef = Swampert.defense; cpuPN.Text = Swampert.Name; cpuAtk = Swampert.attack; imgCpuS.Visibility = Visibility.Visible; cpuMaxHP = Swampert.hp; cpuType = "Water"; }

            if (userPokemon == "Gengar") { CurrentUserHP = gengar.hp; userSpeed = gengar.speed; userDef = gengar.defense; userPN.Text = gengar.Name; userAtk = gengar.attack; imgUserGen.Visibility = Visibility.Visible; pokeHp = gengar.hp; userType = "Ghost"; }
            if (userPokemon == "Garchomp") { CurrentUserHP = garchomp.hp; userSpeed = garchomp.speed; userDef = garchomp.defense; userPN.Text = garchomp.Name; userAtk = garchomp.attack; imgUserG.Visibility = Visibility.Visible; pokeHp = garchomp.hp; userType = "Dragon"; }
            if (userPokemon == "Pikachu") { CurrentUserHP = pikachu.hp; userSpeed = pikachu.speed; userDef = pikachu.defense; userPN.Text = pikachu.Name; userAtk = pikachu.attack; imgUserP.Visibility = Visibility.Visible; pokeHp = pikachu.hp; userType = "Electric"; }
            if (userPokemon == "Snivy") { CurrentUserHP = Snivy.hp; userSpeed = Snivy.speed; userDef = Snivy.defense; userPN.Text = Snivy.Name; userAtk = Snivy.attack; imgUserSn.Visibility = Visibility.Visible; pokeHp = Snivy.hp; userType = "Grass"; }
            if (userPokemon == "Swampert") { CurrentUserHP = Swampert.hp; userSpeed = Swampert.speed; userDef = Swampert.defense; userPN.Text = Swampert.Name; userAtk = Swampert.attack; imgUserS.Visibility = Visibility.Visible; pokeHp = Swampert.hp; userType = "Water"; }
        }
        //Starts Game
        private void gameStart()
        {


            cpuPokemon = game.CpuPokemon;
            currentPokemon = game.UserPokemon;
            changeDefaultPokemon(cpuPokemon, currentPokemon);


            Hbar_1.Maximum = pokeHp;
            Hbar_2.Maximum = cpuMaxHP;

            txtHP1.Text = Hbar_1.Value + " / " + Hbar_1.Maximum;
            txtHP2.Text = Hbar_2.Value + "/" + Hbar_2.Maximum;
        }
        //Updates Current Health in healthBar
        public void updateCHealth()
        {
            if (cpuHP <= 0)
            {

                cpuHP = 0;
                txtHP1.Text = Hbar_1.Value + " / " + Hbar_1.Maximum;

            }
            if (CurrentUserHP <= 0)
            {
                CurrentUserHP = 0;
                txtHP1.Text = Hbar_1.Value + " / " + Hbar_1.Maximum;

            }
            else
            {

                txtHP1.Text = Hbar_1.Value + " / " + Hbar_1.Maximum;
                txtHP2.Text = Hbar_2.Value + "/" + Hbar_2.Maximum;
            }


        }
        //Swaps to move menu
        private void btnFight_Click(object sender, RoutedEventArgs e)
        {
            sGrid.Visibility = Visibility.Hidden;
            mGrid.Visibility = Visibility.Visible;
            if (game.UserPokemon == "Pikachu")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Yellow);
                btnMove2.Background = new SolidColorBrush(Colors.Yellow);
                btnMove3.Background = new SolidColorBrush(Colors.Gray);
                btnMove4.Background = new SolidColorBrush(Colors.Silver);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Yellow);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Yellow);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Silver);

                btnMove1.Content = "Thunderbolt";
                btnMove2.Content = "ElectroShock";
                btnMove3.Content = "Quick Attack";
                btnMove4.Content = "Iron Tail";
            }

            if (game.UserPokemon == "Garchomp")
            {

                btnMove1.Background = new SolidColorBrush(Colors.SandyBrown);
                btnMove2.Background = new SolidColorBrush(Colors.BlueViolet);
                btnMove3.Background = new SolidColorBrush(Colors.BlueViolet);
                btnMove4.Background = new SolidColorBrush(Colors.BlueViolet);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.SandyBrown);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.BlueViolet);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.BlueViolet);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.BlueViolet);


                btnMove1.Content = "Earthquake";
                btnMove2.Content = "Dragon Claw";
                btnMove3.Content = "Dragon Dance";
                btnMove4.Content = "Draco Meteor";
            }
            if (game.UserPokemon == "Gengar")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Brown);
                btnMove2.Background = new SolidColorBrush(Colors.Brown);
                btnMove3.Background = new SolidColorBrush(Colors.Purple);
                btnMove4.Background = new SolidColorBrush(Colors.Purple);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Brown);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Brown);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Purple);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Purple);

                btnMove1.Content = "Shadow Claw";
                btnMove2.Content = "Persuit";
                btnMove3.Content = "Hex";
                btnMove4.Content = "Shadow Ball";
            }
            if (game.UserPokemon == "Snivy")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Green);
                btnMove2.Background = new SolidColorBrush(Colors.Green);
                btnMove3.Background = new SolidColorBrush(Colors.Gray);
                btnMove4.Background = new SolidColorBrush(Colors.Gray);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Green);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Green);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Gray);

                btnMove1.Content = "Leaf Tornado";
                btnMove2.Content = "Vine Whip";
                btnMove3.Content = "Take Down";
                btnMove4.Content = "Quick Attack";
            }
            if (game.UserPokemon == "Swampert")
            {

                btnMove1.Background = new SolidColorBrush(Colors.Blue);
                btnMove2.Background = new SolidColorBrush(Colors.Blue);
                btnMove3.Background = new SolidColorBrush(Colors.Gray);
                btnMove4.Background = new SolidColorBrush(Colors.Blue);

                btn1Border.BorderBrush = new SolidColorBrush(Colors.Blue);
                btn2Border.BorderBrush = new SolidColorBrush(Colors.Blue);
                btn3Border.BorderBrush = new SolidColorBrush(Colors.Gray);
                btn4Border.BorderBrush = new SolidColorBrush(Colors.Blue);

                btnMove1.Content = "Dirty Water";
                btnMove2.Content = "Surf";
                btnMove3.Content = "Take Down";
                btnMove4.Content = "Hydo Pump";
            }


            txtUpdateUser.Text = "Choose a move " + game.PlayerName;


        }
        //Check for crits or misses
        private string critOrMiss()
        {
            string critOrMiss = "";
            int rValue = r.Next(1, 101);
            if (rValue <= 80)
            {
                critOrMiss = "Hit";
            }
            if (rValue >= 91 && rValue <= 100)
            {
                critOrMiss = "Crit";
            }
            if (rValue >= 81 && rValue <= 90)
            {
                critOrMiss = "Missed";
            }

            return critOrMiss;
        }
        //Check totalDmgDealt including defense values

        private int totalDmgDealt(int moveDmg, int pDefense, string critOrMiss, string Mtype, string enemyType)
        {
            int totalDmgDealt = moveDmg - pDefense / 5;
            if (critOrMiss == "Hit")
            {
                totalDmgDealt = moveDmg - pDefense / 5;
            }

            if (critOrMiss == "Missed")
            {
                totalDmgDealt = 0;

            }
            if (critOrMiss == "Crit")
            {
                totalDmgDealt *= 2;
            }

            return totalDmgDealt;
        }
        //Quits game
        private void btnQuit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        //Gets random move for cpu to choose
        public void userMove(int dmgDealt, string critOrMis, string currentMove)
        {
            cpuHP -= totalDmgDealt(dmgDealt, cpuDef, critOrMis,"","");
            Hbar_1.Value = cpuHP;
            updateCHealth();
        }
        public void battle(int dmgDealt, string critOrMis, string critOrMis2, string moveName, bool statMove, string whatStatM, string mType)
        {
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };

            
            if (check_Speed() == currentPokemon)
            {
                txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack ";
                userMove(dmgDealt, critOrMis, moveName);
                checkForWin();
                gif.Visibility = Visibility.Visible;

                timer.Start();
                timer.Tick += (sender, args) =>
                {
                    timer.Stop();
                    cpuMove(critOrMis2);
                    txtUpdateUser.Text = game.CpuPokemon + " Attack " + critOrMis2;
                    sGrid.Visibility = Visibility.Visible;
                    mGrid.Visibility = Visibility.Hidden;
                    gif.Visibility = Visibility.Hidden;
                    checkForWin();
                };
            }
            if (check_Speed() == cpuPokemon)
            {
                txtUpdateUser.Text = game.CpuPokemon + " attack " + critOrMis2;
                cpuMove(critOrMis2);
                checkForWin();
                gif.Visibility = Visibility.Visible;

                timer.Start();
                timer.Tick += (sender, args) =>
                {
                    timer.Stop();
                    userMove(dmgDealt, critOrMis, moveName);
                    txtUpdateUser.Text = currentPokemon + " used " + moveName + "and it was a " + critOrMis + " attack ";
                    checkForWin();
                    sGrid.Visibility = Visibility.Visible;
                    mGrid.Visibility = Visibility.Hidden;
                    gif.Visibility = Visibility.Hidden;
                };

            }
        }
        //This is to check move dmg and using total dmg dealt deals dmg (Want to add speed stats to see who goes first)
        private void btnMove_click(object sender, RoutedEventArgs e)
        {
            string currentMove = (sender as Button).Content.ToString();

            string critOrMis = critOrMiss();
            string critOrMis2 = critOrMiss();
            int i = 0;
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };


            switch (currentMove)
            {
                case "Thunderbolt":
                    mGrid.Visibility = Visibility.Hidden;
                    int dmgDealt = 75;
                    battle(dmgDealt, critOrMis, critOrMis2, "Thunderbolt ", false, "", "Electric");
                    break;
                case "ElectroShock":
                    dmgDealt = 50;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "ElectroShock ", false, "", "Electric");
                    break;
                case "Quick Attack":
                    int previousSpeed = userSpeed;

                    userSpeed = 5000;
                    dmgDealt = 45;
                    mGrid.Visibility = Visibility.Hidden;

                    if (check_Speed() == currentPokemon)
                    {
                        cpuHP -= totalDmgDealt(dmgDealt, cpuDef, critOrMis, "Normal", cpuType);
                        Hbar_1.Value = cpuHP;
                        updateCHealth();
                        txtUpdateUser.Text = currentPokemon + " used quick attack and it was a " + critOrMis + " attack and it was " + effectiveNess;
                        gif.Visibility = Visibility.Visible;
                        timer.Start();
                        timer.Tick += (sender, args) =>
                        {
                            timer.Stop();
                            txtUpdateUser.Text = cpuPokemon + " attack " + critOrMis2;
                            cpuMove(critOrMis2);
                            userSpeed = previousSpeed;
                            sGrid.Visibility = Visibility.Visible;
                            mGrid.Visibility = Visibility.Hidden;
                            gif.Visibility = Visibility.Hidden;
                            checkForWin();
                        };
                    }
                    break;
                case "Earthquake":
                    dmgDealt = 80;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Earthquake ", false, "", "Ground");
                    break;
                case "Iron Tail":
                    dmgDealt = 40;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Iron Tail ", false, "", "Iron");
                    break;
                case "Dragon Claw":
                    dmgDealt = 65;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Dragon Claw ", false, "", "Dragon");
                    break;
                case "Dragon Dance":
                    dmgDealt = 30;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Dragon Drance ", false, "", "Dragon");
                    break;
                case "Draco Meteor":
                    dmgDealt = 140;
                    mGrid.Visibility = Visibility.Hidden;
                    userAtk -= 20;
                    battle(dmgDealt, critOrMis, critOrMis2, "Draco Meteor ", false, "", "Dragon");
                    break;
                case "Shadow Claw":
                    dmgDealt = 60;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Shadow Claw ", false, "", "Dark");
                    break;
                case "Persuit":
                    dmgDealt = 50;
                    if (userSpeed > cpuSpeed) { dmgDealt = 100; }
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Persuit ", false, "", "Dark");
                    break;
                case "Hex":
                    dmgDealt = 75;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Hex ", false, "", "Ghost");
                    break;
                case "Shadow Ball":
                    dmgDealt = 40;
                    if (i >= 1) { dmgDealt = dmgDealt * i; }
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Shadow Ball ", false, "", "Ghost");
                    break;
                case "Leaf Tornado":
                    dmgDealt = 80;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Leaf Tornado ", false, "", "Grass");
                    break;
                case "Vine Whip":
                    dmgDealt = 50;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Vine Whip ", false, "", "Grass");
                    break;

                case "Dirty Water":
                    dmgDealt = 100;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Dirty Water ", false, "", "Water");
                    break;
                case "Surf":
                    dmgDealt = 90;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Surf ", false, "", "Water");
                    break;
                case "Take Down":
                    dmgDealt = 80;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Take Down ", false, "", "Normal");
                    break;
                case "Hydro Pump":
                    dmgDealt = 90;
                    mGrid.Visibility = Visibility.Hidden;
                    battle(dmgDealt, critOrMis, critOrMis2, "Hydro Pump ", false, currentPokemon + "'s Defense Increased", "Water");
                    break;
            }
        }
        private string check_Speed()
        {
            string whoFirst = "";
            if (cpuSpeed == userSpeed)
            {
                cpuPokemon = cpuPokemon + "1";
                whoFirst = currentPokemon;
            }
            else if (cpuSpeed > userSpeed)
            {
                whoFirst = cpuPokemon;
            }
            else if (userSpeed > cpuSpeed)
            {
                whoFirst = currentPokemon;
            }


            return whoFirst;
        }
        //Checks to see if someone won
        private void checkForWin()
        {

            if (Hbar_1.Value <= 0)
            {
                imgCpuP.Visibility = Visibility.Hidden;
                imgCpuS.Visibility = Visibility.Hidden;
                imgCpuSn.Visibility = Visibility.Hidden;
                imgCpuGen.Visibility = Visibility.Hidden;
                imgCpuG.Visibility = Visibility.Hidden;
                updateCHealth();

                txtUpdateUser.Text = game.CpuPokemon + " has feinted the winner is " + game.PlayerName;
            }
            else if (Hbar_2.Value <= 0)
            {
                imgUserP.Visibility = Visibility.Hidden;
                imgUserS.Visibility = Visibility.Hidden;
                imgUserSn.Visibility = Visibility.Hidden;
                imgUserGen.Visibility = Visibility.Hidden;
                imgUserG.Visibility = Visibility.Hidden;
                updateCHealth();
                txtUpdateUser.Text = game.UserPokemon + " has feineted the winner is CPU";
            }
            else if (Hbar_1.Value <= 0 && Hbar_2.Value <= 0)
            {
                imgCpuP.Visibility = Visibility.Hidden;
                imgCpuS.Visibility = Visibility.Hidden;
                imgCpuSn.Visibility = Visibility.Hidden;
                imgCpuGen.Visibility = Visibility.Hidden;
                imgCpuG.Visibility = Visibility.Hidden;

                imgUserP.Visibility = Visibility.Hidden;
                imgUserS.Visibility = Visibility.Hidden;
                imgUserSn.Visibility = Visibility.Hidden;
                imgUserGen.Visibility = Visibility.Hidden;
                imgUserG.Visibility = Visibility.Hidden;
                updateCHealth();

                txtUpdateUser.Text = "Game Was tied";
            }


        }

    }
}