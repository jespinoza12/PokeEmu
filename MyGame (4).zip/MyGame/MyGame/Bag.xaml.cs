﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MyGame
{
    /// <summary>
    /// Interaction logic for Bag.xaml
    /// </summary>
    public partial class Bag : Window
    {
        public Bag()
        {
            InitializeComponent();

            potionImage.Visibility = Visibility.Hidden;
            superPotionImage.Visibility = Visibility.Hidden;
            hyperPotionImage.Visibility = Visibility.Hidden;
        }

      

        private void btnPotion_Click(object sender, RoutedEventArgs e)
        {
            int count;
            int.TryParse(countPotion.Content.ToString(), out count);
            if (count != 0)
            {
                count--;
                countPotion.Content = count.ToString();
                ((MainWindow)Application.Current.MainWindow).potionRestore();
                this.Hide();
            }
        }

        private void btnSuperPotion_Click(object sender, RoutedEventArgs e)
        {
            int count;
            int.TryParse(countSuperPotion.Content.ToString(), out count);
            if (count != 0)
            {
                count--;
                countSuperPotion.Content = count.ToString();
                ((MainWindow)Application.Current.MainWindow).superPotionRestore();
                this.Hide();
            }
        }

        private void btnHyperPotion_Click(object sender, RoutedEventArgs e)
        {
            int count;
            int.TryParse(countHyperPotion.Content.ToString(), out count);
            if (count != 0)
            {
                count--;
                countHyperPotion.Content = count.ToString();
                ((MainWindow)Application.Current.MainWindow).hyperPotionRestore();
                this.Hide();
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnPotion_MouseMove(object sender, MouseEventArgs e)
        {
            potionDesc.Visibility = Visibility.Visible;
            superPotionDesc.Visibility = Visibility.Hidden;
            hyperPotionDesc.Visibility = Visibility.Hidden;
            cancelDesc.Visibility = Visibility.Hidden;

            potionDesc.Content = "Restores the HP of one Pokémon by 20 points.";

            potionImage.Visibility = Visibility.Visible;
            superPotionImage.Visibility = Visibility.Hidden;
            hyperPotionImage.Visibility = Visibility.Hidden;
        }

        private void btnSuperPotion_MouseMove(object sender, MouseEventArgs e)
        {
            potionDesc.Visibility = Visibility.Hidden;
            superPotionDesc.Visibility = Visibility.Visible;
            hyperPotionDesc.Visibility = Visibility.Hidden;
            cancelDesc.Visibility = Visibility.Hidden;

            superPotionDesc.Content = "Restores the HP of one Pokémon by 50 points.";

            potionImage.Visibility = Visibility.Hidden;
            superPotionImage.Visibility = Visibility.Visible;
            hyperPotionImage.Visibility = Visibility.Hidden;
        }

        private void btnHyperPotion_MouseMove(object sender, MouseEventArgs e)
        {
            potionDesc.Visibility = Visibility.Hidden;
            superPotionDesc.Visibility = Visibility.Hidden;
            hyperPotionDesc.Visibility = Visibility.Visible;
            cancelDesc.Visibility = Visibility.Hidden;

            hyperPotionDesc.Content = "Restores the HP of one Pokémon by 120 points.";

            potionImage.Visibility = Visibility.Hidden;
            superPotionImage.Visibility = Visibility.Hidden;
            hyperPotionImage.Visibility = Visibility.Visible;
        }

        private void btnCancel_MouseMove(object sender, MouseEventArgs e)
        {
            potionDesc.Visibility = Visibility.Hidden;
            superPotionDesc.Visibility = Visibility.Hidden;
            hyperPotionDesc.Visibility = Visibility.Hidden;
            cancelDesc.Visibility = Visibility.Visible;

            cancelDesc.Content = "Exit out of bag.";

            potionImage.Visibility = Visibility.Hidden;
            superPotionImage.Visibility = Visibility.Hidden;
            hyperPotionImage.Visibility = Visibility.Hidden;
        }
    }
}
